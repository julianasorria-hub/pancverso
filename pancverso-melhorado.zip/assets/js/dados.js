/* =====================================================================
   PANCverso — dados do site (espécies, lotes e configuração)
   ---------------------------------------------------------------------
   Este é o ÚNICO arquivo que precisa ser editado para incluir espécies,
   lotes ou mudar contatos. Todas as páginas leem daqui.

   Lotes e produtores cadastrados no painel da pesquisadora ficam salvos
   no navegador dela. Para publicá-los para todos, use "Exportar >
   Baixar dados.js" no painel e substitua este arquivo no servidor.
   Os lotes abaixo são REGISTROS DE TESTE ("teste: true").

   Campos de lote seguem o Apêndice A do projeto de dissertação (Quadro A.1).
   Somente campos de acesso PÚBLICO aparecem aqui. Contato do produtor,
   endereço exato, coordenadas, fornecedor, nota de qualidade e
   responsável pelo registro ficam APENAS no painel restrito (LGPD).
   ===================================================================== */

window.PANC = {
  config: {
    // Endereço para onde aponta o QR Code de cada lote. Deixe vazio ("")
    // para usar o endereço do próprio site: .../lote.html#PANC-2026-0003
    // Ao publicar num domínio fixo, preencha, por exemplo:
    // "https://www.seudominio.com.br/lote.html#{codigo}"
    urlLote: "",
    email: "julianasorria@gmail.com",
    whatsapp: "5524993028587",
    telefoneExibicao: "(24) 99302-8587",
    // Questionário do consumidor (Apêndice D). Fica DESATIVADO até a
    // aprovação do Comitê de Ética em Pesquisa (CEP).
    pesquisaAtiva: false,
    // Contador de acessos (GoatCounter: sem cookies e sem dados pessoais).
    // Preencha com o código da conta, por exemplo "pancverso" para
    // https://pancverso.goatcounter.com. Vazio ("") = contador desligado.
    contador: "",
    atualizadoEm: "2026-11-26"
  },

  /* Barra de notícias da página inicial. tipo: "Como usar", "Novidade"
     ou "Atualização". link é opcional. {especies} vira o total de
     espécies do catálogo. */
  noticias: [
    { tipo: "Como usar", texto: "Aponte a câmera do celular para o QR Code da embalagem ou digite o código do lote (ex.: PANC-2026-0003) na página inicial.", link: "index.html#codigo" },
    { tipo: "Novidade", texto: "Catálogo ampliado para {especies} espécies, com base no guia Capacitação em PANC do Programa CapacitAgro (PESAGRO-RIO, 2024).", link: "catalogo.html" },
    { tipo: "Novidade", texto: "Conheça os produtores: cada um tem foto da propriedade, espécies cultivadas e lotes publicados.", link: "produtores.html" },
    { tipo: "Como usar", texto: "Na dúvida sobre uma planta, não coma. Confira a ficha da espécie e os cuidados antes de preparar.", link: "catalogo.html#dicas" },
    { tipo: "Novidade", texto: "O jogo Adivinhe a PANC agora fica no Material didático, com foto misteriosa, sequência de acertos e modo contra o relógio.", link: "material-didatico.html#jogo" },
    { tipo: "Atualização", texto: "Os lotes publicados são registros de teste. Os lotes dos produtores participantes entram no teste piloto, após aprovação do Comitê de Ética em Pesquisa.", link: "sobre.html" },
    { tipo: "Como usar", texto: "É produtor de PANC na região de Vassouras? Fale com a pesquisadora pelo WhatsApp (24) 99302-8587 para participar.", link: "produtores.html#participar" },
    { tipo: "Atualização", texto: "Site atualizado em 26/11/2026: barra de notícias, fotos das propriedades, novas espécies e logos dos parceiros." }
  ],

  /* Temperos e especiarias não convencionais (TENC) citados no guia do
     Programa CapacitAgro (2024). Só a lista de nomes. */
  tenc: ["Alho-social", "Macassá", "Nirá", "Alfazema", "Hortelã-pimenta", "Erva-baleeira", "Guasca", "Cúrcuma", "Pimenta-do-reino",
    "Colônia", "Chambá", "Capim-limão", "Cravo-da-índia", "Erva-jabuti", "Melissa", "Alho-poró", "Capuchinha (folha e flor)",
    "Arnica-paulista", "Coentrão (folha e flor)", "Coentro-caboclo", "Orégano (flores)", "Tomilho-limão", "Jambu", "Estévia",
    "Lavanda", "Erva-cidreira", "Funcho", "Mostarda", "Hortelã-silvestre", "Flor de hortelã", "Manjericão-anis",
    "Manjericão (flores)", "Menta-americana"],

  /* Produtores: somente campos PÚBLICOS. Contato e endereço ficam no
     painel da pesquisadora. "consentimento: false" oculta o nome. */
  produtores: [
    {
      id: "horta-univassouras",
      nome: "Horta Agroecológica da Universidade de Vassouras",
      propriedade: "Horta Agroecológica – campus Vassouras",
      municipio: "Vassouras", uf: "RJ",
      tipo: "Horta agroecológica",
      sistema: "Agroecológico",
      historia: "Horta de ensino e pesquisa usada como local de produção de referência para a etiqueta-piloto do PANCverso.",
      consentimento: true,
      teste: true,
      foto: "assets/img/produtores/horta-univassouras.jpg",
      fotoCredito: {"titulo": "The People's Garden (20221021-FPAC-LSC-0046).jpg", "autor": "USDAgov", "licenca": "Public domain", "licencaUrl": "", "fonte": "https://commons.wikimedia.org/wiki/File:The_People's_Garden_(20221021-FPAC-LSC-0046).jpg", "alteracoes": "Imagem redimensionada."}
    },
    /* Os três produtores abaixo são SIMULADOS ("simulado: true"): servem
       só para demonstrar a página. Fotos ilustrativas do Wikimedia Commons.
       Apague-os antes do teste piloto. */
    {
      id: "sitio-boa-vista",
      nome: "Sítio Boa Vista",
      propriedade: "Sítio Boa Vista – zona rural",
      municipio: "Vassouras", uf: "RJ",
      tipo: "Agricultura familiar",
      sistema: "Orgânico (em transição)",
      historia: "Sítio de base familiar que cultiva hortaliças para a feira da cidade e mantém uma cerca viva de ora-pro-nóbis. Começou a separar canteiros só para PANC em 2025.",
      consentimento: true,
      teste: true, simulado: true,
      foto: "assets/img/produtores/sitio-boa-vista.jpg",
      fotoCredito: {"titulo": "Vegetable garden 1.JPG", "autor": "P199", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Vegetable_garden_1.JPG", "alteracoes": "Imagem redimensionada."}
    },
    {
      id: "quintal-serra-velha",
      nome: "Quintal Agroflorestal Serra Velha",
      propriedade: "Quintal agroflorestal",
      municipio: "Mendes", uf: "RJ",
      tipo: "Sistema agroflorestal",
      sistema: "Agroflorestal",
      historia: "Quintal com árvores frutíferas, bananeiras e plantas espontâneas manejadas. A coleta das PANC é feita no próprio quintal, sem uso de agrotóxicos.",
      consentimento: true,
      teste: true, simulado: true,
      foto: "assets/img/produtores/quintal-serra-velha.jpg",
      fotoCredito: {"titulo": "Domestic herbal patch rectangularpattern.JPG", "autor": "KVDP", "licenca": "Public domain", "licencaUrl": "", "fonte": "https://commons.wikimedia.org/wiki/File:Domestic_herbal_patch_rectangularpattern.JPG", "alteracoes": "Imagem redimensionada."}
    },
    {
      id: "coletivo-flores-da-roca",
      nome: "Coletivo Flores da Roça",
      propriedade: "Horta coletiva",
      municipio: "Barra do Piraí", uf: "RJ",
      tipo: "Grupo de agricultoras",
      sistema: "Agroecológico",
      historia: "Grupo de agricultoras que cultiva flores alimentícias e hortaliças em canteiros coletivos e vende em feiras agroecológicas da região.",
      consentimento: true,
      teste: true, simulado: true,
      foto: "assets/img/produtores/coletivo-flores-da-roca.jpg",
      fotoCredito: {"titulo": "Gemeinschaftsgarten Magdolna Straße, Blumen, 2025 Magdolnanegyed.jpg", "autor": "Globetrotter19", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Gemeinschaftsgarten_Magdolna_Stra%C3%9Fe,_Blumen,_2025_Magdolnanegyed.jpg", "alteracoes": "Imagem redimensionada."}
    }
  ],

  especies: [
    {
      id: "ora-pro-nobis",
      nome: "Ora-pro-nóbis",
      cientifico: "Pereskia aculeata Mill.",
      familia: "Cactaceae",
      origem: "Nativa do Brasil",
      imagem: "assets/img/ora-pro-nobis.jpg",
      credito: {"titulo": "Pereskia aculeata (Scott Zona) 001.jpg", "autor": "Scott Zona from Miami, Florida, USA", "licenca": "CC BY 2.0", "licencaUrl": "https://creativecommons.org/licenses/by/2.0", "fonte": "https://commons.wikimedia.org/wiki/File:Pereskia_aculeata_(Scott_Zona)_001.jpg", "alteracoes": "Imagem redimensionada."},
      cor: "#e2efda",
      apelido: "Carne de pobre",
      resumo: "Trepadeira com espinhos e folhas carnudas, conhecida como “carne de pobre” pelo teor de proteína das folhas. Tradicional na culinária mineira.",
      descricao: "Cacto trepador nativo, de ramos com espinhos e folhas verdes, carnudas e brilhantes. É muito usado como cerca viva. As flores são brancas com centro alaranjado e os frutos, pequenos e amarelos. As folhas soltam uma leve mucilagem (“baba”) ao cozinhar, que ajuda a dar liga em massas e farofas.",
      sabor: "Suave, levemente herbáceo; textura macia quando refogada",
      partes: ["Folhas", "Flores", "Frutos"],
      usos: ["Refogados", "Farofas", "Tortas e pães", "Farinha das folhas secas"],
      nutricao: {
        parte: "Folhas, massa seca",
        itens: [["Proteína", "28,4 g"], ["Fibra alimentar total", "39,1 g"]],
        nota: "Fonte de cálcio, magnésio, manganês, zinco e vitaminas A e C.",
        fonte: "Takeiti et al. (2009)"
      },
      preparo: [
        "Lave as folhas uma a uma, retirando-as do ramo com cuidado por causa dos espinhos.",
        "Higienize (veja o passo a passo abaixo) e seque bem.",
        "Para refogar, corte em tiras e cozinhe por poucos minutos: o ponto é quando murcham e ficam verde-escuras.",
        "As folhas secas à sombra e trituradas viram farinha para pães, bolos e massas."
      ],
      cuidados: [
        "Use luvas na colheita: os ramos têm espinhos.",
        "Folhas jovens e médias são mais macias; descarte as amareladas."
      ],
      identificacao: "Ramos lenhosos com pares de espinhos na base de cada folha; folhas inteiras, carnudas, sem pelos.",
      receitas: [
        {
          titulo: "Refogado de ora-pro-nóbis",
          rende: "2 porções · 10 min",
          ingredientes: ["2 xícaras de folhas higienizadas, em tiras", "1 dente de alho picado", "½ cebola picada", "1 colher (sopa) de azeite ou óleo", "Sal a gosto"],
          modo: ["Doure a cebola e o alho no azeite.", "Junte as folhas e mexa até murcharem (3 a 5 minutos).", "Acerte o sal e sirva com arroz, angu ou ovos."]
        },
        {
          titulo: "Farofa de ora-pro-nóbis",
          rende: "4 porções · 15 min",
          ingredientes: ["1 xícara de folhas em tiras finas", "1 xícara de farinha de mandioca", "1 cebola picada", "2 colheres (sopa) de manteiga ou óleo", "Sal e cheiro-verde a gosto"],
          modo: ["Refogue a cebola na gordura até dourar.", "Junte a ora-pro-nóbis e mexa por 2 minutos.", "Acrescente a farinha aos poucos, mexendo até ficar soltinha. Finalize com sal e cheiro-verde."]
        }
      ],
      pistas: [
        ["Família", "Sou da família dos cactos (Cactaceae), mas não pareço um cacto."],
        ["Aparência", "Sou trepadeira, tenho espinhos nos ramos e folhas carnudas."],
        ["Uso", "Viro cerca viva e entro no frango com angu de Minas Gerais."],
        ["Destaque", "Minhas folhas secas têm cerca de 28 g de proteína a cada 100 g."],
        ["Apelido", "Me chamam de “carne de pobre”."]
      ]
    },
    {
      id: "taioba",
      nome: "Taioba",
      cientifico: "Xanthosoma taioba E.G.Gonç.",
      familia: "Araceae",
      origem: "Nativa da América tropical",
      imagem: "assets/img/taioba.jpg",
      credito: {"titulo": "Taioba.jpg", "autor": "Davillis", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Taioba.jpg", "alteracoes": "Imagem redimensionada."},
      cor: "#d9ecd6",
      apelido: "O coração verde da roça",
      resumo: "Hortaliça de folhas largas em forma de coração que substitui a couve e o espinafre em refogados. Deve ser consumida sempre cozida.",
      descricao: "Planta de folhas grandes, em formato de coração alongado, com talo longo que se prende na borda da folha. Muito presente em quintais e roças do Sudeste. As folhas são a parte mais usada; o rizoma também é comestível depois de cozido.",
      sabor: "Lembra couve e espinafre, mais macia depois de cozida",
      partes: ["Folhas (sempre cozidas)", "Talos", "Rizoma (cozido)"],
      usos: ["Refogados", "Sopas e caldos", "Recheios de tortas", "Substituta da couve"],
      nutricao: {
        parte: "Folhas cruas, massa fresca (consumir cozidas)",
        itens: [["Energia", "34 kcal"], ["Proteína", "2,9 g"], ["Fibra alimentar", "4,5 g"], ["Cálcio", "141 mg"], ["Ferro", "1,9 mg"], ["Vitamina C", "17,9 mg"]],
        nota: "",
        fonte: "NEPA/UNICAMP – TACO (2006)"
      },
      preparo: [
        "Retire o talo e a nervura central mais grossa.",
        "Higienize, enrole as folhas e corte em tiras finas.",
        "Cozinhe bem: refogue e deixe cozinhar tampado por cerca de 10 minutos, até ficar bem macia.",
        "Nunca consuma a taioba crua, nem em sucos verdes."
      ],
      cuidados: [
        "Sempre cozida: crua, a folha irrita a boca e a garganta por causa dos cristais de oxalato de cálcio (BRASIL, 2010).",
        "Há plantas parecidas da mesma família que são tóxicas, como a taioba-brava e a comigo-ninguém-pode. Compre de produtor identificado ou confira a ficha do lote."
      ],
      identificacao: "Na taioba, o talo se prende na borda da folha (no ponto entre os dois “lóbulos”), e uma nervura acompanha todo o contorno da folha.",
      receitas: [
        {
          titulo: "Taioba refogada",
          rende: "3 porções · 20 min",
          ingredientes: ["6 folhas de taioba higienizadas", "2 dentes de alho", "1 colher (sopa) de azeite ou óleo", "Sal a gosto"],
          modo: ["Retire os talos, enrole as folhas e corte em tiras finas.", "Doure o alho, junte a taioba e mexa até murchar.", "Tampe e cozinhe em fogo baixo por cerca de 10 minutos, até ficar bem macia. Acerte o sal."]
        },
        {
          titulo: "Caldo verde de taioba",
          rende: "4 porções · 40 min",
          ingredientes: ["4 batatas médias", "1 cebola", "2 dentes de alho", "4 folhas de taioba em tiras finas", "1 litro de água", "Azeite e sal a gosto"],
          modo: ["Cozinhe as batatas com cebola e alho na água até desmancharem; bata e volte ao fogo.", "Junte a taioba e cozinhe por 10 minutos, mexendo de vez em quando.", "Finalize com azeite e sal."]
        }
      ],
      pistas: [
        ["Família", "Sou da família Araceae, a mesma do antúrio e do copo-de-leite."],
        ["Aparência", "Tenho folhas enormes em forma de coração e talo comprido."],
        ["Cuidado", "Só posso ser comida depois de cozida."],
        ["Destaque", "Tenho cerca de 141 mg de cálcio a cada 100 g de folha."],
        ["Uso", "Substituo a couve no refogado e no caldo verde."]
      ]
    },
    {
      id: "beldroega",
      nome: "Beldroega",
      cientifico: "Portulaca oleracea L.",
      familia: "Portulacaceae",
      origem: "Espontânea, presente em todo o Brasil",
      imagem: "assets/img/beldroega.jpg",
      credito: {"titulo": "Portulaca oleracea, 2022-06-18, South Side, 01.jpg", "autor": "Cbaile19", "licenca": "CC0", "licencaUrl": "https://creativecommons.org/publicdomain/zero/1.0/deed.en", "fonte": "https://commons.wikimedia.org/wiki/File:Portulaca_oleracea,_2022-06-18,_South_Side,_01.jpg", "alteracoes": "Imagem redimensionada."},
      cor: "#e7efd2",
      apelido: "Ômega-3 da horta",
      resumo: "Suculenta rasteira de sabor levemente ácido e salgado. Fonte vegetal de ômega-3 (ácido alfa-linolênico).",
      descricao: "Planta rasteira e suculenta que nasce sozinha em hortas, canteiros e calçadas. Tem caules avermelhados, folhas pequenas e carnudas em formato de gota e flores amarelas que se abrem pela manhã.",
      sabor: "Levemente ácido e salgado, crocante quando crua",
      partes: ["Folhas", "Ramos tenros"],
      usos: ["Saladas cruas", "Refogados", "Omeletes", "Sopas"],
      nutricao: {
        parte: "Folhas, massa fresca",
        itens: [["Ácido alfa-linolênico (ômega-3)", "300 a 400 mg"], ["Vitamina C", "26,6 mg"], ["Alfa-tocoferol (vitamina E)", "12,2 mg"], ["Betacaroteno", "1,9 mg"]],
        nota: "",
        fonte: "Simopoulos et al. (1992)"
      },
      preparo: [
        "Escolha ramos tenros, sem flores secas.",
        "Higienize bem, pois cresce rente ao solo.",
        "Crua, vai em saladas; cozida, use como espinafre em refogados, omeletes e sopas."
      ],
      cuidados: [
        "Tem teor elevado de oxalato (UDDIN et al., 2014): prefira consumo moderado. Quem tem histórico de cálculo renal deve conversar com um profissional de saúde.",
        "Não confunda com plantas rasteiras do gênero Euphorbia (como a erva-de-santa-luzia), que soltam um leite branco ao quebrar o ramo. A beldroega não tem esse leite."
      ],
      identificacao: "Caule liso, carnudo e avermelhado; folhas grossas em forma de gota; sem leite branco ao partir o ramo.",
      receitas: [
        {
          titulo: "Salada de beldroega com tomate",
          rende: "2 porções · 10 min",
          ingredientes: ["2 xícaras de beldroega higienizada", "2 tomates em cubos", "½ cebola roxa em fatias finas", "Azeite, limão e sal a gosto"],
          modo: ["Separe folhas e ramos tenros.", "Misture com o tomate e a cebola.", "Tempere na hora de servir."]
        },
        {
          titulo: "Omelete de beldroega",
          rende: "1 porção · 10 min",
          ingredientes: ["2 ovos", "½ xícara de beldroega picada", "1 colher (chá) de óleo", "Sal e pimenta a gosto"],
          modo: ["Bata os ovos com sal e pimenta.", "Refogue a beldroega no óleo por 1 minuto.", "Despeje os ovos por cima e cozinhe dos dois lados."]
        }
      ],
      pistas: [
        ["Família", "Sou da família Portulacaceae."],
        ["Aparência", "Sou rasteira, suculenta e tenho caules avermelhados."],
        ["Sabor", "Tenho gosto levemente ácido e salgado."],
        ["Destaque", "Sou fonte vegetal de ômega-3."],
        ["Onde cresço", "Nasço sozinha em canteiros e frestas de calçada."]
      ]
    },
    {
      id: "capuchinha",
      nome: "Capuchinha",
      cientifico: "Tropaeolum majus L.",
      familia: "Tropaeolaceae",
      origem: "Nativa dos Andes",
      imagem: "assets/img/capuchinha.jpg",
      credito: {"titulo": "Yellow and red Tropaeolum majus (Garden nasturtium).jpg", "autor": "Mary Hutchison", "licenca": "CC0", "licencaUrl": "https://creativecommons.org/publicdomain/zero/1.0/deed.en", "fonte": "https://commons.wikimedia.org/wiki/File:Yellow_and_red_Tropaeolum_majus_(Garden_nasturtium).jpg", "alteracoes": "Imagem redimensionada."},
      cor: "#fbe7cf",
      apelido: "Flor comestível picante",
      resumo: "Trepadeira de folhas redondas e flores laranja, amarelas e vermelhas. Folhas, flores e sementes são comestíveis e têm sabor picante, como o agrião.",
      descricao: "Planta ornamental e comestível, de folhas arredondadas com o talo preso no centro (como um guarda-chuva) e flores vistosas em tons quentes. As sementes verdes podem ser conservadas em vinagre como alcaparras.",
      sabor: "Picante e refrescante, parecido com agrião",
      partes: ["Folhas", "Flores", "Sementes verdes"],
      usos: ["Saladas", "Decoração de pratos", "Conservas das sementes", "Pesto de folhas"],
      nutricao: {
        parte: "Flores, massa fresca",
        itens: [["Vitamina C", "80,2 mg"]],
        nota: "Rica em carotenoides, especialmente luteína.",
        fonte: "Souza et al. (2020); Embrapa Hortaliças (2017)"
      },
      preparo: [
        "Colha as flores pela manhã e use no mesmo dia; guarde em geladeira, em pote fechado.",
        "Higienize com delicadeza para não machucar as pétalas.",
        "Use folhas e flores cruas em saladas; as sementes verdes vão para a conserva."
      ],
      cuidados: [
        "Use apenas flores produzidas para alimentação. Flores de floricultura podem ter recebido agrotóxicos não permitidos para alimentos.",
        "Retire pequenos insetos que costumam ficar dentro das flores."
      ],
      identificacao: "Folhas redondas com o talo preso no centro e nervuras que irradiam; flores em forma de funil com um “esporão” atrás.",
      receitas: [
        {
          titulo: "Salada colorida com capuchinha",
          rende: "2 porções · 10 min",
          ingredientes: ["1 maço de folhas verdes (alface, rúcula)", "8 folhas de capuchinha", "8 flores de capuchinha", "Azeite, limão e sal a gosto"],
          modo: ["Rasgue as folhas verdes e as de capuchinha.", "Tempere e arrume as flores por cima na hora de servir."]
        },
        {
          titulo: "Falsa alcaparra de sementes",
          rende: "1 pote pequeno · 2 semanas de cura",
          ingredientes: ["1 xícara de sementes verdes de capuchinha", "Água e sal para a salmoura", "Vinagre para cobrir", "1 folha de louro (opcional)"],
          modo: ["Deixe as sementes em água com sal por 1 dia, trocando a água duas vezes.", "Escorra e coloque em pote de vidro limpo com o louro.", "Cubra com vinagre, tampe e guarde na geladeira por 2 semanas antes de usar."]
        }
      ],
      pistas: [
        ["Família", "Sou da família Tropaeolaceae."],
        ["Aparência", "Tenho folhas redondas como pequenos guarda-chuvas."],
        ["Sabor", "Sou picante, parecida com agrião."],
        ["Destaque", "Minhas flores têm cerca de 80 mg de vitamina C a cada 100 g."],
        ["Uso", "Minhas flores laranja enfeitam saladas e minhas sementes viram “alcaparra”."]
      ]
    },
    /* GUIA-INICIO */
    /* ---- Espécies do guia Capacitação em PANC (Programa CapacitAgro, PESAGRO-RIO, 2024).
       Ficha resumida: sem nutrição e receitas ("nutricao" ausente). ---- */
    {"id": "agriaozinho-silvestre", "nome": "Agriãozinho-silvestre", "cientifico": "Cardamine bonariensis", "familia": "Brassicaceae", "origem": "Europa", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/agriaozinho-silvestre.jpg", "credito": {"titulo": "Cardamine bonariensis- Río Negro, Palmar, Suelo uliginoso al margen de la Cañada del Pastoreo 4.jpg", "autor": "Andrés González", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Cardamine_bonariensis-_R%C3%ADo_Negro,_Palmar,_Suelo_uliginoso_al_margen_de_la_Ca%C3%B1ada_del_Pastoreo_4.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhinhas macias e picantes, parecidas com as mini verduras vendidas como baby leaf.", "partes": ["Planta inteira"], "usos": ["Saladas", "Finalização de pratos"], "uso": "A planta inteira é comestível, com sabor picante e textura macia. As vagens, também picantes, ficam boas na finalização de pratos e combinam com queijos.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "almeirao-roxo", "nome": "Almeirão-roxo", "cientifico": "Lactuca canadensis", "familia": "Asteraceae", "origem": "América do Norte (EUA e Canadá)", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/almeirao-roxo.jpg", "credito": {"titulo": "Lactuca canadensis WILD LETTUCE (3362992724).jpg", "autor": "George F Mayfield from chicago area, USA", "licenca": "CC BY-SA 2.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/2.0", "fonte": "https://commons.wikimedia.org/wiki/File:Lactuca_canadensis_WILD_LETTUCE_(3362992724).jpg", "alteracoes": "Imagem redimensionada."},"cor": "#e2efda", "resumo": "Folhas que vão bem refogadas como verdura ou cruas, quando jovens, na salada.", "partes": ["Folhas"],"usos": ["Refogados", "Saladas", "Recheios"],"uso": "Refogue como qualquer verdura de folha. As folhas jovens podem ir cruas na salada e também entram em recheios de tortas, omeletes e panquecas.", "fonte": "Programa CapacitAgro (2024)", "apelido": "Prima alta da alface", "descricao": "Planta da família da alface, de folhas longas e recortadas, muitas vezes com a nervura arroxeada. Pode crescer bastante e, ao florescer, forma uma haste alta com pequenas flores amarelas. Ao ser cortada, solta um leite branco, como a alface.", "sabor": "Levemente amargo, mais suave nas folhas novas", "nutricao": {"parte": "Folhas frescas, por 100 g", "itens": [["Proteína", "1,7 g"],["Fibra alimentar", "3,4 g"],["Cálcio", "98,6 mg"],["Ferro", "1,0 mg"],["Magnésio", "30,4 mg"],["Potássio", "533,9 mg"]],"nota": "No estudo, a espécie aparece também como almeirão-de-árvore. Plantas cultivadas no Bioma Cerrado; os teores variam com o solo e o cultivo.", "fonte": "Botrel et al. (2020)"},"preparo": ["Prefira folhas novas, que são mais macias e menos amargas.", "Higienize e corte em tiras finas.", "Use cruas na salada ou refogue rapidamente, como couve."],"cuidados": ["O leite branco que sai do corte é normal nesta planta.", "Há outras plantas de folhas recortadas e leitosas que não são alimentícias. Consuma só plantas identificadas com segurança ou compradas de produtor identificado."],"identificacao": "Folhas longas e recortadas, com nervura central às vezes arroxeada; leite branco ao cortar; haste alta com pequenas flores amarelas quando floresce.", "receitas": [{"titulo": "Almeirão-roxo refogado", "rende": "3 porções · 15 min", "ingredientes": ["1 maço de almeirão-roxo", "2 dentes de alho", "1 colher (sopa) de azeite", "Sal a gosto"],"modo": ["Higienize as folhas, enrole e corte em tiras finas.", "Doure o alho no azeite.", "Junte o almeirão, mexa por 2 a 3 minutos e acerte o sal."]},{"titulo": "Salada de folhas novas", "rende": "4 porções · 10 min", "ingredientes": ["Folhas novas de almeirão-roxo", "1 laranja em gomos", "1/2 cebola roxa em fatias finas", "Azeite, limão e sal a gosto"],"modo": ["Higienize as folhas e rasgue com as mãos.", "Junte a laranja e a cebola.", "Tempere com azeite, limão e sal na hora de servir. O doce da laranja equilibra o amargor."]}],"pistas": [["Família", "Sou da família Asteraceae, prima da alface."],["Aparência", "Minhas folhas são longas e recortadas, com nervura às vezes roxa."],["Segredo", "Solto um leite branco quando me cortam."],["Sabor", "Sou levemente amargo."],["Destaque", "Tenho mais de 500 mg de potássio em 100 g de folhas."]]},
    {"id": "begonia-do-brejo", "nome": "Begônia-do-brejo", "cientifico": "Begonia cucullata", "familia": "Begoniaceae", "origem": "América do Sul", "categoria": "Flor alimentícia", "propagacao": "Estaquia", "imagem": "assets/img/especies/begonia-do-brejo.jpg", "credito": {"titulo": "Begonia Cucullata Willd.jpg", "autor": "WWELNUR", "licenca": "CC BY 4.0", "licencaUrl": "https://creativecommons.org/licenses/by/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Begonia_Cucullata_Willd.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flores azedinhas, queridas pelas crianças, que colorem saladas.", "partes": ["Folhas", "Flores"], "usos": ["Saladas", "Suco verde", "Decoração comestível"], "uso": "As flores, de sabor azedinho, vão cruas na salada e na decoração de pratos. As folhas jovens entram no suco verde, na salada ou, depois de cozidas, em recheios.", "atencao": "Rica em ácido oxálico: consuma com moderação.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "brilhantina", "nome": "Brilhantina", "cientifico": "Pilea microphylla", "familia": "Urticaceae", "origem": "América tropical", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/brilhantina.jpg", "credito": {"titulo": "Starr 030807-0140 Pilea microphylla.jpg", "autor": "Forest & Kim Starr", "licenca": "CC BY 3.0", "licencaUrl": "https://creativecommons.org/licenses/by/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Starr_030807-0140_Pilea_microphylla.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Plantinha delicada que aparece em vasos e calçadas e enriquece bolinhos e recheios.", "partes": ["Parte aérea"], "usos": ["Refogados", "Bolinhos", "Recheios"], "uso": "Use toda a parte aérea refogada, branqueada ou cozida. Fica ótima para enriquecer bolinhos e recheios.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "capicoba", "nome": "Capiçoba", "cientifico": "Erechtites valerianifolius", "familia": "Asteraceae", "origem": "Nativa da costa brasileira", "categoria": "PANC", "propagacao": "Sementes", "cor": "#e2efda", "resumo": "Planta nativa do litoral brasileiro, usada como verdura refogada ou crua quando jovem.", "partes": ["Folhas"], "usos": ["Refogados", "Saladas", "Recheios"], "uso": "Refogue como verdura. As folhas jovens podem ir cruas na salada e em recheios de tortas, omeletes e panquecas.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "caruru", "nome": "Caruru", "cientifico": "Amaranthus deflexus", "familia": "Amaranthaceae", "origem": "África", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/caruru.jpg", "credito": {"titulo": "Amaranthus deflexus12.jpg", "autor": "Victor M. Vicente Selvas", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Amaranthus_deflexus12.jpg", "alteracoes": "Imagem redimensionada."},"cor": "#e2efda", "resumo": "Folhas para refogar e sementes que podem ser usadas como a quinoa.", "partes": ["Folhas", "Sementes"],"usos": ["Refogados", "Saladas", "Grãos como quinoa"],"uso": "As folhas são refogadas como verdura, ou usadas cruas quando jovens, em saladas e recheios. As sementes têm uso semelhante ao da quinoa.", "fonte": "Programa CapacitAgro (2024)", "apelido": "O mato que é verdura", "descricao": "Planta de porte baixo que nasce sozinha em hortas, roças e terrenos. Tem folhas ovais, com a ponta levemente recortada, caule sem espinhos e flores verdes miúdas reunidas em espigas na ponta dos ramos.", "sabor": "Suave, lembra o espinafre", "nutricao": {"parte": "Folhas frescas, por 100 g", "itens": [["Proteína", "5,6 g"],["Fibra alimentar", "7,4 g"],["Cálcio", "139,7 mg"],["Ferro", "2,1 mg"],["Magnésio", "66,1 mg"],["Potássio", "304,5 mg"]],"nota": "Plantas cultivadas no Bioma Cerrado; os teores variam com o solo e o cultivo.", "fonte": "Botrel et al. (2020)"},"preparo": ["Use as folhas e as pontas tenras dos ramos; descarte os talos mais grossos.", "Higienize bem, pois a planta cresce rente ao solo.", "Refogue como espinafre ou couve. Folhas bem novas podem ir cruas na salada."],"cuidados": ["Colha apenas em locais sem agrotóxicos e longe de beira de estrada, esgoto ou entulho.", "Há várias espécies de caruru parecidas. Consuma só plantas identificadas com segurança ou compradas de produtor identificado."],"identificacao": "Folhas ovais e alternadas, com a ponta um pouco recortada; caule sem espinhos; flores verdes e miúdas em espigas na ponta dos ramos.", "receitas": [{"titulo": "Caruru refogado", "rende": "3 porções · 15 min", "ingredientes": ["1 maço de caruru (folhas e pontas tenras)", "2 dentes de alho picados", "1/2 cebola picada", "1 colher (sopa) de azeite ou óleo", "Sal a gosto"],"modo": ["Higienize as folhas e pique grosseiramente.", "Doure a cebola e o alho no azeite.", "Junte o caruru e mexa por 3 a 5 minutos, até murchar. Acerte o sal."]},{"titulo": "Omelete de caruru", "rende": "2 porções · 15 min", "ingredientes": ["3 ovos", "1 xícara de folhas de caruru picadas", "1/2 tomate picado", "Sal e cheiro-verde a gosto", "Fio de óleo"],"modo": ["Refogue rapidamente o caruru no óleo até murchar.", "Bata os ovos com sal, junte o caruru, o tomate e o cheiro-verde.", "Despeje na frigideira untada e cozinhe em fogo baixo, virando para dourar dos dois lados."]}],"pistas": [["Família", "Sou da família Amaranthaceae, a mesma do amaranto e da beterraba."],["Aparência", "Tenho flores verdes miudinhas em espigas na ponta dos ramos."],["Onde cresço", "Nasço sozinho na horta e muita gente me arranca achando que sou mato."],["Destaque", "Tenho cerca de 140 mg de cálcio em 100 g de folhas."],["Uso", "Minhas sementes podem ser usadas como a quinoa."]]},
    {"id": "celosia", "nome": "Celósia", "cientifico": "Celosia argentea", "familia": "Amaranthaceae", "origem": "Ásia (Índia)", "categoria": "Flor alimentícia", "propagacao": "Sementes", "imagem": "assets/img/especies/celosia.jpg", "credito": {"titulo": "Celosia argentea0.jpg", "autor": "Autor não identificado no Commons", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Celosia_argentea0.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Folhas comestíveis e flores que dão cor rosada às bebidas.", "partes": ["Folhas", "Flores", "Sementes"], "usos": ["Refogados", "Infusões coloridas", "Grãos como quinoa"], "uso": "As folhas vão refogadas ou cruas, quando jovens, em saladas e recheios. A infusão das flores deixa as bebidas rosadas e as sementes são usadas como a quinoa.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "coentro-caboclo", "nome": "Coentro-caboclo", "cientifico": "Eryngium foetidum", "familia": "Apiaceae", "origem": "Amazônia e América tropical", "categoria": "TENC", "propagacao": "Sementes e divisão de touceiras", "imagem": "assets/img/especies/coentro-caboclo.jpg", "credito": {"titulo": "Hombay3.jpg", "autor": "Autor não identificado no Commons", "licenca": "Copyrighted free use", "licencaUrl": "", "fonte": "https://commons.wikimedia.org/wiki/File:Hombay3.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#fbefd2", "resumo": "Folha aromática com sabor de coentro, muito usada na Região Norte.", "partes": ["Folhas"], "usos": ["Tempero", "Peixes e frutos do mar"], "uso": "Use as folhas cruas ou refogadas, como verdura ou tempero. Combina com peixes e frutos do mar, como o coentro comum.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "crepe-do-japao", "nome": "Crepe-do-japão", "cientifico": "Youngia japonica", "familia": "Asteraceae", "origem": "Japão e China", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/crepe-do-japao.jpg", "credito": {"titulo": "Youngja japonica1.jpg", "autor": "Sphl", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Youngja_japonica1.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhas que lembram mini alfaces, ótimas para salada.", "partes": ["Folhas", "Flores"], "usos": ["Saladas", "Refogados"], "uso": "As folhas são perfeitas para saladas. As flores também são comestíveis, mas murcham logo depois da colheita; podem ser refogadas junto com as folhas.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "dente-de-leao", "nome": "Dente-de-leão", "cientifico": "Taraxacum officinale", "familia": "Asteraceae", "origem": "Europa e Ásia", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/dente-de-leao.jpg", "credito": {"titulo": "Taraxacum officinale in Remiremont, France - 2022-05-03 - 02.jpg", "autor": "Mathieu Kappler", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Taraxacum_officinale_in_Remiremont,_France_-_2022-05-03_-_02.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Planta inteira aproveitável: folhas, flores, sementes e até a raiz torrada.", "partes": ["Folhas", "Flores", "Sementes", "Raízes"], "usos": ["Refogados", "Saladas", "Tempurá", "Bebida tipo café"], "uso": "As folhas podem ser refogadas, cruas na salada quando jovens ou usadas em recheios. As flores vão na salada, em tempurá ou na decoração. As sementes enriquecem pães e bolinhos e as raízes torradas dão uma infusão com sabor parecido com o do café.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "erva-baleeira", "nome": "Erva-baleeira", "cientifico": "Varronia curassavica (sin. Cordia verbenacea)", "familia": "Boraginaceae", "origem": "Nativa do litoral brasileiro", "categoria": "TENC", "propagacao": "Sementes", "imagem": "assets/img/especies/erva-baleeira.jpg", "credito": {"titulo": "Cordia curassavica 1.jpg", "autor": "Marcia  Stefani", "licenca": "CC BY 2.0", "licencaUrl": "https://creativecommons.org/licenses/by/2.0", "fonte": "https://commons.wikimedia.org/wiki/File:Cordia_curassavica_1.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#fbefd2", "resumo": "Folha aromática que pode substituir o louro no feijão.", "partes": ["Folhas"], "usos": ["Tempero", "Feijão"], "uso": "As folhas aromáticas servem de condimento e podem substituir o louro no feijão.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "erva-pepino", "nome": "Erva-pepino", "cientifico": "Parietaria debilis", "familia": "Urticaceae", "origem": "Europa, Ásia e África", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/erva-pepino.jpg", "credito": {"titulo": "Parietaria judaica y debilis (14716254787).jpg", "autor": "Pato Novoa from Valparaíso, Chile", "licenca": "CC BY-SA 2.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/2.0", "fonte": "https://commons.wikimedia.org/wiki/File:Parietaria_judaica_y_debilis_(14716254787).jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Erva tenra com sabor de pepino.", "partes": ["Ramos com folhas"], "usos": ["Saladas", "Pesto", "Vinagrete"], "uso": "Erva macia e saborosa, com gosto de pepino. Vai muito bem em saladas, pesto, vinagrete ou na finalização de pratos.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "espinafre-do-mato", "nome": "Espinafre-do-mato", "cientifico": "Alternanthera tenella", "familia": "Amaranthaceae", "origem": "Regiões tropicais menos úmidas do Brasil", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/espinafre-do-mato.jpg", "credito": {"titulo": "Starr 080103-1342 Alternanthera tenella.jpg", "autor": "Forest & Kim Starr", "licenca": "CC BY 3.0", "licencaUrl": "https://creativecommons.org/licenses/by/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Starr_080103-1342_Alternanthera_tenella.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhas que se refogam como espinafre e colorem massas de verde.", "partes": ["Folhas"], "usos": ["Refogados", "Massas coloridas"], "uso": "Consuma sempre refogada, como o espinafre. É uma ótima fonte de cor verde para massas.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "guasca", "nome": "Guasca", "cientifico": "Galinsoga parviflora", "familia": "Asteraceae", "origem": "Costa oeste da América do Sul", "categoria": "TENC", "propagacao": "Sementes", "imagem": "assets/img/especies/guasca.jpg", "credito": {"titulo": "Galinsoga1.jpg", "autor": "Autor não identificado no Commons", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Galinsoga1.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#fbefd2", "resumo": "Tempero tradicional da Colômbia, que revela o aroma quando aquecido.", "partes": ["Ramos com folhas"], "usos": ["Tempero", "Sopas", "Saladas"], "uso": "As folhas ficam aromáticas depois de aquecidas. Pode ir crua em sucos e saladas ou refogada. Na Colômbia, é indispensável no ajiaco, uma sopa de batatas e milho.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "jambu", "nome": "Jambu", "cientifico": "Acmella oleracea (sin. Spilanthes oleracea)", "familia": "Asteraceae", "origem": "Amazônia", "categoria": "TENC", "propagacao": "Sementes e estacas", "imagem": "assets/img/especies/jambu.jpg", "credito": {"titulo": "Acmella oleracea 001.JPG", "autor": "H. Zell", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Acmella_oleracea_001.JPG", "alteracoes": "Imagem redimensionada."},"cor": "#fbefd2", "resumo": "Comum na Região Norte, causa um leve formigamento na boca.", "partes": ["Ramos com folhas", "Flores"],"usos": ["Pratos com peixe", "Tacacá", "Bebidas"],"uso": "As folhas são consumidas cozidas, sobretudo com peixe, e são ingrediente do tacacá e do pato no tucupi. As flores também são comestíveis e usadas em bebidas. O espilantol, presente na planta, provoca salivação e um leve formigamento.", "atencao": "É um ótimo exemplo de que o “não convencional” depende da região: no Norte, o jambu é ingrediente do dia a dia.", "fonte": "Programa CapacitAgro (2024)", "apelido": "A folha que faz formigar", "descricao": "Planta baixa, de ramos macios, folhas ovais e flores amarelas em forma de botão. Muito usada no Pará, onde é vendida em maços nas feiras e entra em pratos típicos.", "sabor": "Levemente picante; provoca formigamento e dormência na boca", "nutricao": {"parte": "Folhas frescas, por 100 g", "itens": [["Proteína", "3,9 g"],["Fibra alimentar", "6,5 g"],["Cálcio", "69,4 mg"],["Ferro", "3,8 mg"],["Magnésio", "27,8 mg"],["Potássio", "230,1 mg"]],"nota": "Plantas cultivadas no Bioma Cerrado; os teores variam com o solo e o cultivo.", "fonte": "Botrel et al. (2020)"},"preparo": ["Use folhas, ramos tenros e flores.", "Higienize bem os maços.", "Na culinária paraense, costuma ser escaldado rapidamente e entra no fim do preparo de caldos, do tacacá e do pato no tucupi."],"cuidados": ["O formigamento vem do espilantol, substância natural da planta, e passa depois de alguns minutos.", "Para quem nunca provou, comece com pouca quantidade."],"identificacao": "Folhas opostas, ovais, com a borda levemente serrilhada; flores amarelas em forma de botão, sem pétalas aparentes, às vezes com a ponta avermelhada.", "receitas": [{"titulo": "Arroz com jambu", "rende": "4 porções · 30 min", "ingredientes": ["2 xícaras de arroz", "1 maço de jambu (folhas e flores)", "1 cebola picada", "2 dentes de alho", "4 xícaras de água quente", "Óleo e sal a gosto"],"modo": ["Escalde o jambu por 1 minuto em água fervente, escorra e pique.", "Refogue cebola e alho, junte o arroz e a água quente com sal e cozinhe.", "Quando o arroz estiver quase seco, misture o jambu, tampe e deixe terminar o cozimento."]},{"titulo": "Caldo de peixe com jambu", "rende": "4 porções · 40 min", "ingredientes": ["500 g de peixe em postas", "1 maço de jambu", "1 cebola, 1 tomate e 2 dentes de alho picados", "1 litro de água", "Cheiro-verde, limão e sal a gosto"],"modo": ["Tempere o peixe com limão e sal.", "Refogue cebola, alho e tomate, junte a água e deixe ferver; acrescente o peixe e cozinhe por 15 minutos.", "Escalde o jambu, junte ao caldo nos últimos 5 minutos e finalize com cheiro-verde."]}],"pistas": [["Família", "Sou da família Asteraceae, a mesma do girassol."],["Aparência", "Minhas flores amarelas parecem pequenos botões."],["Sensação", "Deixo a boca formigando e dormente."],["Região", "Sou estrela da culinária do Pará."],["Uso", "Entro no tacacá e no pato no tucupi."]]},
    {"id": "maria-pretinha", "nome": "Maria-pretinha", "cientifico": "Solanum americanum", "familia": "Solanaceae", "origem": "Américas", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/maria-pretinha.jpg", "credito": {"titulo": "Starr 010520-0074 Solanum americanum.jpg", "autor": "Forest & Kim Starr", "licenca": "CC BY 3.0", "licencaUrl": "https://creativecommons.org/licenses/by/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Starr_010520-0074_Solanum_americanum.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Frutinhos pretos maduros para geleias e sucos; folhas sempre refogadas.", "partes": ["Folhas", "Frutos maduros"], "usos": ["Frutos in natura", "Geleias", "Refogados"], "uso": "Os frutos maduros podem ser comidos in natura e viram geleias, sorvetes, sucos e molhos. As folhas são consumidas como verdura, sempre refogadas.", "atencao": "Atenção: os frutos verdes são tóxicos. Coma apenas os frutos bem pretos e maduros.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "moranguinho-silvestre", "nome": "Moranguinho-silvestre", "cientifico": "Rubus rosifolius", "familia": "Rosaceae", "origem": "África, Ásia e Oceania", "categoria": "PANC", "propagacao": "Rizomas e brotos", "imagem": "assets/img/especies/moranguinho-silvestre.jpg", "credito": {"titulo": "Rubus rosifolius 2.jpg", "autor": "Franz Xaver", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Rubus_rosifolius_2.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Frutinha vermelha silvestre para comer no pé ou fazer geleia.", "partes": ["Frutos", "Flores"], "usos": ["Frutos in natura", "Geleias", "Sobremesas"], "uso": "Os frutos são consumidos in natura ou em geleias, refrescos, caldas e sobremesas. As flores servem de decoração comestível.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "picao-preto", "nome": "Picão-preto", "cientifico": "Bidens pilosa", "familia": "Asteraceae", "origem": "América tropical", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/picao-preto.jpg", "credito": {"titulo": "Bidens pilosa.jpg", "autor": "Tauʻolunga", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Bidens_pilosa.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Planta espontânea muito comum, aproveitada como hortaliça cozida.", "partes": ["Ramos com folhas", "Flores"], "usos": ["Refogados", "Chá gelado"], "uso": "As folhas são consumidas como hortaliça, de preferência cozidas, e também dão um chá gelado. As flores podem ir junto com os ramos.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "tanchagem", "nome": "Tanchagem", "cientifico": "Plantago australis", "familia": "Plantaginaceae", "origem": "Sul e Sudeste do Brasil", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/tanchagem.jpg", "credito": {"titulo": "Plantago australis 1.jpg", "autor": "Stan Shebs", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Plantago_australis_1.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhas jovens para salada e sementes que formam gel, como a chia.", "partes": ["Folhas", "Sementes", "Inflorescências"], "usos": ["Saladas", "Refogados", "Gel como chia"], "uso": "Folhas bem jovens vão cruas na salada e, cortadas finas, podem ser refogadas. As sementes hidratadas formam um gel parecido com o da chia. A haste floral fica saborosa empanada.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "terramicina", "nome": "Terramicina", "cientifico": "Alternanthera brasiliana", "familia": "Amaranthaceae", "origem": "Brasil", "categoria": "PANC", "propagacao": "Estacas", "imagem": "assets/img/especies/terramicina.jpg", "credito": {"titulo": "Alternanthera-brasiliana2.jpg", "autor": "CostaPPPR", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Alternanthera-brasiliana2.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhas arroxeadas que dão cor às infusões e vão cozidas como verdura.", "partes": ["Folhas"], "usos": ["Refogados", "Infusões coloridas"], "uso": "Tem potencial corante em infusões. As folhas jovens são consumidas como verdura, sempre cozidas, com sabor suave e boa textura.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "trevo-amazonico", "nome": "Trevo-amazônico", "cientifico": "Oxalis barrelieri", "familia": "Oxalidaceae", "origem": "Brasil (Amazônia)", "categoria": "PANC", "propagacao": "Sementes", "imagem": "assets/img/especies/trevo-amazonico.jpg", "credito": {"titulo": "Oxalis barrelieri - Calincing tanah - Lengkongwetan 2020 3 cropped hdr.jpg", "autor": "Aris riyanto", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Oxalis_barrelieri_-_Calincing_tanah_-_Lengkongwetan_2020_3_cropped_hdr.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Toda a parte aérea é comestível, com sabor azedinho.", "partes": ["Ramos com folhas", "Frutos", "Flores"], "usos": ["Saladas", "Cozidos"], "uso": "Toda a parte aérea pode ser consumida in natura ou cozida. O sabor é ácido.", "atencao": "Rico em ácido oxálico: consuma com moderação.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "trevo-azedo", "nome": "Trevo-azedo", "cientifico": "Oxalis latifolia", "familia": "Oxalidaceae", "origem": "México", "categoria": "PANC", "propagacao": "Bulbos e bulbilhos", "imagem": "assets/img/especies/trevo-azedo.jpg", "credito": {"titulo": "Oxalis latifolia 3.jpg", "autor": "Franz Xaver", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Oxalis_latifolia_3.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Trevo de folhas grandes, azedinho, muito usado na finalização de pratos.", "partes": ["Parte aérea"], "usos": ["Saladas", "Decoração comestível"], "uso": "Pode ir cru na salada e é muito usado na decoração e finalização de pratos.", "atencao": "Rico em ácido oxálico: deve ser evitado por pessoas com doenças renais.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "zebrina", "nome": "Zebrina", "cientifico": "Tradescantia zebrina", "familia": "Commelinaceae", "origem": "México e América Central", "categoria": "PANC", "propagacao": "Estacas", "imagem": "assets/img/especies/zebrina.jpg", "credito": {"titulo": "Zebrina pendula 20060521 2 closer.jpg", "autor": "Ruestz", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Zebrina_pendula_20060521_2_closer.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#e2efda", "resumo": "Folhas listradas usadas na bebida mexicana água de matali.", "partes": ["Folhas"], "usos": ["Bebidas", "Cozidos"], "uso": "É a base da água de matali, bebida tradicional mexicana. Como outras trapoeirabas, pode ser consumida depois de cozida.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "beijo", "nome": "Beijo", "cientifico": "Impatiens walleriana", "familia": "Balsaminaceae", "origem": "África", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/beijo.jpg", "credito": {"titulo": "Impatiens walleriana3.jpg", "autor": "KENPEI", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Impatiens_walleriana3.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flor de sabor neutro que colore saladas e rende boas geleias.", "partes": ["Flores"], "usos": ["Saladas", "Geleias"], "uso": "As flores têm sabor neutro, mas a textura e as cores deixam a salada mais atraente. É ótima para geleia.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "bougainvillea", "nome": "Buganvília", "cientifico": "Bougainvillea glabra / B. spectabilis", "familia": "Nyctaginaceae", "origem": "Brasil", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/bougainvillea.jpg", "credito": {"titulo": "Bougainvillea-Flowers-KayEss-1.jpeg", "autor": "KayEss", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Bougainvillea-Flowers-KayEss-1.jpeg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Comemos as brácteas coloridas, que também tingem bebidas e massas.", "partes": ["Brácteas"], "usos": ["Saladas", "Corante natural"], "uso": "O que se consome são as brácteas, folhas modificadas e coloridas que envolvem as flores (as flores em si são fibrosas). As brácteas vão cruas na salada e sua infusão colore bebidas e massas.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "clitoria", "nome": "Clitória", "cientifico": "Clitoria ternatea", "familia": "Fabaceae", "origem": "Ásia tropical, Península Arábica e África", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/clitoria.jpg", "credito": {"titulo": "Clitoria ternatea - Asian pigeonwings in Bhopal, India September 2025.jpg", "autor": "Suyash.dwivedi", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Clitoria_ternatea_-_Asian_pigeonwings_in_Bhopal,_India_September_2025.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flor que dá um azul natural às bebidas, que muda para roxo ou rosa com limão.", "partes": ["Flores"], "usos": ["Corante azul", "Bebidas", "Saladas"], "uso": "Fornece corante azul natural. A infusão muda para roxo ou rosa quando recebe um ingrediente ácido, como limão. As flores também vão cruas na salada.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "cosmo", "nome": "Cosmo", "cientifico": "Cosmos sulphureus", "familia": "Asteraceae", "origem": "América Central", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/cosmo.jpg", "credito": {"titulo": "Cosmos-KayEss.jpeg", "autor": "KayEss", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Cosmos-KayEss.jpeg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Pétalas laranja que colorem refogados como o açafrão.", "partes": ["Pétalas"], "usos": ["Corante", "Saladas"], "uso": "Algumas pétalas no refogado dão cor ao prato, como o açafrão. Também vão cruas na salada.", "atencao": "Prefira só as pétalas: o miolo é um pouco amargo e tem pólen, que pode causar alergia.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "cravina", "nome": "Cravina", "cientifico": "Dianthus chinensis", "familia": "Caryophyllaceae", "origem": "Ásia e leste europeu", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/cravina.jpg", "credito": {"titulo": "Dianthus chinensis korea 2010.JPG", "autor": "Jjw", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Dianthus_chinensis_korea_2010.JPG", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Pétalas coloridas para saladas e finalização de pratos.", "partes": ["Pétalas"], "usos": ["Saladas", "Finalização de pratos"], "uso": "Use as pétalas destacadas em saladas ou na finalização de pratos.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "dalia", "nome": "Dália", "cientifico": "Dahlia spp.", "familia": "Asteraceae", "origem": "México", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/dalia.jpg", "credito": {"titulo": ",00 0904 Dahlia × pinnata.jpg", "autor": "W. Bulach", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:,00_0904_Dahlia_%C3%97_pinnata.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Muitas pétalas, que vão na salada ou secas como corante.", "partes": ["Pétalas"], "usos": ["Saladas", "Corante"], "uso": "As pétalas podem ser consumidas como hortaliça, colorindo saladas; retire o miolo. Desidratadas, as pétalas de cores fortes viram corante.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "ixora", "nome": "Ixora", "cientifico": "Ixora coccinea", "familia": "Rubiaceae", "origem": "Ásia tropical e Madagascar", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/ixora.jpg", "credito": {"titulo": "Colpfl16.jpg", "autor": "Louise Wolff (darina)", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Colpfl16.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flores firmes que mantêm a forma no calor: ótimas em tempurá.", "partes": ["Flores"], "usos": ["Tempurá", "Salteados", "Saladas"], "uso": "As flores mantêm a estrutura mesmo cozidas. Para começar, faça tempurá ou salteie com shoyu e outros vegetais. Também podem ir cruas na salada ou em recheios.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "madressilva", "nome": "Madressilva", "cientifico": "Lonicera japonica", "familia": "Caprifoliaceae", "origem": "China e Japão", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/madressilva.jpg", "credito": {"titulo": "Lonicera japonicum1.jpg", "autor": "J.F. Gaffard Jeffdelonge at fr.wikipedia", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Lonicera_japonicum1.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flores brancas e amarelas, muito perfumadas, para refrescos e doces.", "partes": ["Flores"], "usos": ["Refrescos", "Sorvetes", "Bolos e biscoitos"], "uso": "As flores aromáticas vão em refrescos, sorvetes e massas de bolos e biscoitos. Também podem ir na salada, sem exagero.", "atencao": "Consuma apenas as flores, com moderação.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "malvavisco", "nome": "Malvavisco", "cientifico": "Malvaviscus arboreus", "familia": "Malvaceae", "origem": "América Central e norte da América do Sul", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/malvavisco.jpg", "credito": {"titulo": "Starr 071024-0101 Malvaviscus arboreus.jpg", "autor": "Forest & Kim Starr", "licenca": "CC BY 3.0", "licencaUrl": "https://creativecommons.org/licenses/by/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Starr_071024-0101_Malvaviscus_arboreus.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flor vermelha que vira uma geleia parecida com a de morango.", "partes": ["Flores"], "usos": ["Geleias", "Saladas"], "uso": "Pétalas macias e de sabor neutro. Perfeitas para geleia, que fica com aparência de geleia de morango. Também vão cruas, sem o miolo, em saladas.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "tumbergia", "nome": "Tumbérgia", "cientifico": "Thunbergia grandiflora", "familia": "Acanthaceae", "origem": "Ásia", "categoria": "Flor alimentícia", "imagem": "assets/img/especies/tumbergia.jpg", "credito": {"titulo": "Thunbergia grandiflora flower.jpg", "autor": "PapiPijuan", "licenca": "CC BY-SA 4.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/4.0", "fonte": "https://commons.wikimedia.org/wiki/File:Thunbergia_grandiflora_flower.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#f6e3e5", "resumo": "Flor azul com aroma e sabor de cogumelo-paris.", "partes": ["Flores"], "usos": ["Caldos", "Risotos", "Recheios"], "uso": "Pode ser comida crua logo depois da colheita, porque murcha rápido, ou refogada (perde a cor). Aromatiza caldos e risotos e serve de recheio para quiches, empadões e pastéis.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "mangara", "nome": "Mangará (coração da bananeira)", "cientifico": "Musa spp.", "familia": "Musaceae", "origem": "Sudeste Asiático", "categoria": "Parte não convencional", "imagem": "assets/img/especies/mangara.jpg", "credito": {"titulo": "Banana flower edit2.jpg", "autor": "jjron (obra derivada de foto original)", "licenca": "CC BY-SA 2.5", "licencaUrl": "https://creativecommons.org/licenses/by-sa/2.5", "fonte": "https://commons.wikimedia.org/wiki/File:Banana_flower_edit2.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#efe6d6", "resumo": "Da bananeira, além da fruta, comemos o mangará, o palmito, a banana verde e a casca.", "partes": ["Inflorescência (mangará)", "Palmito do pseudocaule", "Banana verde", "Casca"], "usos": ["Refogados", "Conservas", "Biomassa de banana verde"], "uso": "A banana é convencional, mas a bananeira tem outras partes comestíveis: o mangará (umbigo ou coração), o palmito do pseudocaule para conserva, a banana verde (biomassa, farinha e chips) e a própria casca.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "mamao-verde", "nome": "Mamão verde", "cientifico": "Carica papaya", "familia": "Caricaceae", "origem": "América tropical", "categoria": "Parte não convencional", "imagem": "assets/img/especies/mamao-verde.jpg", "credito": {"titulo": "Raw papaya fruits on tree.jpg", "autor": "Mokkie", "licenca": "CC BY-SA 3.0", "licencaUrl": "https://creativecommons.org/licenses/by-sa/3.0", "fonte": "https://commons.wikimedia.org/wiki/File:Raw_papaya_fruits_on_tree.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#efe6d6", "resumo": "O mamão verde vira legume; a medula do caule vira doce e as sementes, condimento.", "partes": ["Fruto verde", "Medula do caule", "Sementes"], "usos": ["Como legume", "Doces", "Condimento"], "uso": "Além do mamão maduro, o mamoeiro oferece o fruto verde, usado como legume, a medula do caule, ralada para doces, e as sementes, usadas como condimento.", "fonte": "Programa CapacitAgro (2024)"},
    {"id": "jaca-verde", "nome": "Jaca verde", "cientifico": "Artocarpus heterophyllus", "familia": "Moraceae", "origem": "Índia", "categoria": "Parte não convencional", "imagem": "assets/img/especies/jaca-verde.jpg", "credito": {"titulo": "Artocarpus heterophyllus fruits at tree.jpg", "autor": "Photo taken by User:Ahoerstemeier on June 28, 2003 in Chaiya, Surat Thani Province, Thailand.", "licenca": "CC BY-SA 3.0", "licencaUrl": "http://creativecommons.org/licenses/by-sa/3.0/", "fonte": "https://commons.wikimedia.org/wiki/File:Artocarpus_heterophyllus_fruits_at_tree.jpg", "alteracoes": "Imagem redimensionada."}, "cor": "#efe6d6", "resumo": "A jaca verde, de sabor neutro, substitui a carne em receitas; as sementes viram castanhas.", "partes": ["Fruto verde", "Sementes"], "usos": ["Substituto de carne", "Castanhas cozidas"], "uso": "O fruto verde tem textura fibrosa e sabor neutro, e substitui a carne desfiada em muitas receitas. As sementes, cozidas ou assadas, são consumidas como castanhas.", "fonte": "Programa CapacitAgro (2024)"}
    /* GUIA-FIM */
  ],

  /* ---------------- Lotes (REGISTROS DE TESTE) ---------------- */
  lotes: [
    {
      codigo: "PANC-2026-0001",
      teste: true,
      especie: "taioba",
      produtor: "horta-univassouras",
      origem: "Cultivo próprio",
      inicio: "2026-04-06",
      colheita: "2026-10-14",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Composto orgânico produzido na própria horta", irrigacao: "Regador manual", pragas: "Sem agrotóxicos; catação manual" },
      pesoKg: 3.2,
      partes: ["Folhas"],
      processamento: "Limpeza, retirada dos talos e higienização.",
      categoria: "In natura",
      preparos: ["Refogados e omeletes", "Sopas e caldos", "Recheios"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0002",
      teste: true,
      especie: "capuchinha",
      produtor: "horta-univassouras",
      origem: "Cultivo próprio",
      inicio: "2026-07-02",
      colheita: "2026-10-21",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Composto orgânico", irrigacao: "Gotejamento", pragas: "Sem agrotóxicos; consórcio com ervas aromáticas" },
      pesoKg: 0.6,
      partes: ["Flores", "Folhas"],
      processamento: "Colheita pela manhã, retirada de insetos e higienização delicada.",
      categoria: "In natura",
      preparos: ["Saladas cruas"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0003",
      teste: true,
      especie: "ora-pro-nobis",
      produtor: "horta-univassouras",
      origem: "Cultivo próprio",
      inicio: "2026-02-10",
      colheita: "2026-11-04",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Composto orgânico e cobertura morta", irrigacao: "Regador manual", pragas: "Sem agrotóxicos" },
      pesoKg: 2.5,
      partes: ["Folhas"],
      processamento: "Retirada das folhas dos ramos com luvas, limpeza e higienização.",
      categoria: "In natura",
      preparos: ["Refogados e omeletes", "Pães, bolos e biscoitos", "Recheios"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0004",
      teste: true,
      especie: "beldroega",
      produtor: "horta-univassouras",
      origem: "Cultivo próprio (planta espontânea manejada nos canteiros)",
      inicio: "2026-10-01",
      colheita: "2026-11-11",
      metodo: "Não se aplica (planta espontânea)",
      manejo: { adubacao: "Não se aplica", irrigacao: "Chuva e irrigação dos canteiros", pragas: "Sem agrotóxicos" },
      pesoKg: 1.1,
      partes: ["Folhas", "Ramos tenros"],
      processamento: "Seleção dos ramos tenros e higienização.",
      categoria: "In natura",
      preparos: ["Saladas cruas", "Refogados e omeletes"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0005",
      teste: true,
      especie: "ora-pro-nobis",
      produtor: "horta-univassouras",
      origem: "Cultivo próprio",
      inicio: "2026-02-10",
      colheita: "2026-11-18",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Composto orgânico e cobertura morta", irrigacao: "Regador manual", pragas: "Sem agrotóxicos" },
      pesoKg: 1.8,
      partes: ["Folhas"],
      processamento: "Folhas secas à sombra por 5 dias, trituradas e peneiradas.",
      categoria: "Ingrediente seco",
      preparos: ["Pães, bolos e biscoitos", "Aproveitamento integral"],
      ingredientes: "Farinha de folhas de ora-pro-nóbis (100%). Use de 1 a 2 colheres de sopa para cada 500 g de farinha de trigo em pães e bolos."
    },
    {
      codigo: "PANC-2026-0006",
      teste: true,
      especie: "ora-pro-nobis",
      produtor: "sitio-boa-vista",
      origem: "Cultivo próprio",
      inicio: "2025-09-15",
      colheita: "2026-11-10",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Esterco curtido e composto", irrigacao: "Aspersão", pragas: "Sem agrotóxicos" },
      pesoKg: 2.5,
      partes: ["Folhas"],
      processamento: "Folhas destacadas dos ramos, lavadas e embaladas em maço.",
      categoria: "In natura",
      preparos: ["Refogados e omeletes", "Farofas"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0007",
      teste: true,
      especie: "mangara",
      produtor: "quintal-serra-velha",
      origem: "Coleta em área natural",
      inicio: "2026-08-01",
      colheita: "2026-11-05",
      metodo: "Agroflorestal",
      manejo: { adubacao: "Cobertura com folhas e restos de poda", irrigacao: "Chuva", pragas: "Sem agrotóxicos" },
      pesoKg: 4,
      partes: ["Inflorescência (mangará)"],
      processamento: "Retirada das brácteas externas e higienização.",
      categoria: "In natura",
      preparos: ["Refogados", "Recheios"],
      ingredientes: ""
    },
    {
      codigo: "PANC-2026-0008",
      teste: true,
      especie: "clitoria",
      produtor: "coletivo-flores-da-roca",
      origem: "Cultivo próprio",
      inicio: "2026-06-20",
      colheita: "2026-11-20",
      metodo: "Orgânico / agroecológico",
      manejo: { adubacao: "Composto orgânico", irrigacao: "Gotejamento", pragas: "Sem agrotóxicos; barreira com ervas aromáticas" },
      pesoKg: 0.3,
      partes: ["Flores"],
      processamento: "Flores colhidas pela manhã, secas à sombra e embaladas.",
      categoria: "Ingrediente seco",
      preparos: ["Chás e bebidas", "Corante natural"],
      ingredientes: "Flores secas de clitória (100%). Uma colher de sopa em 300 ml de água quente dá uma infusão azul; com limão, fica roxa."
    }
  ]
};

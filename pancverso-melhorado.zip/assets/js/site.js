/* =====================================================================
   PANCverso — comportamento das páginas (sem dependências externas,
   exceto o gerador de QR Code em assets/js/vendor/qrcode.js, MIT).
   Cada página define <body data-page="...">; a função correspondente
   em PAGES é executada ao carregar.
   ===================================================================== */
(function () {
  "use strict";
  var D = window.PANC;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function fmtData(iso) {
    if (!iso) return "—";
    var p = iso.split("-");
    return p[2] + "/" + p[1] + "/" + p[0];
  }
  function fmtKg(n) { return (n == null) ? "—" : String(n).replace(".", ",") + " kg"; }
  /* ---------- Camada de dados ----------
     Base pública: assets/js/dados.js. Cadastros feitos no painel ficam
     no navegador (localStorage, chave abaixo) e são somados à base. */
  var CHAVE = "pancverso:dados:v1";
  function lerLocal() {
    var v = {};
    try { v = JSON.parse(localStorage.getItem(CHAVE)) || {}; } catch (e) { v = {}; }
    v.lotes = v.lotes || []; v.produtores = v.produtores || []; v.arquivados = v.arquivados || [];
    v.privado = v.privado || {}; v.privadoProdutor = v.privadoProdutor || {}; v.acessos = v.acessos || {};
    return v;
  }
  function gravarLocal(v) { try { localStorage.setItem(CHAVE, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function todosProdutores() { return D.produtores.concat(lerLocal().produtores); }
  function produtor(id) { return todosProdutores().find(function (p) { return p.id === id; }); }
  // Visão pública do produtor: sem consentimento, o nome não aparece.
  function produtorPublico(id) {
    var p = produtor(id) || { nome: "Produtor participante", propriedade: "—", municipio: "—", uf: "", tipo: "—" };
    if (p.consentimento === false) {
      return Object.assign({}, p, { nome: "Produtor participante", propriedade: "Nome não divulgado", historia: "" });
    }
    return p;
  }
  function todosLotes(incluirArquivados) {
    var loc = lerLocal();
    return D.lotes.concat(loc.lotes).filter(function (l) { return incluirArquivados || (loc.arquivados.indexOf(l.codigo) < 0 && !l.arquivado); })
      .map(function (l) { return Object.assign({}, l, { _p: produtorPublico(l.produtor) }); });
  }
  var LOTES = todosLotes(false);
  function especie(id) { return D.especies.find(function (e) { return e.id === id; }); }
  // Fichas completas (com nutrição e receitas) x fichas do guia CapacitAgro.
  function completa(e) { return !!(e && e.nutricao); }
  function categoria(e) { return e.categoria || "PANC"; }
  function lote(cod) { return LOTES.find(function (l) { return l.codigo === cod; }); }
  function lotesDe(id) { return LOTES.filter(function (l) { return l.especie === id; }); }
  function recentes(n) { return LOTES.slice().sort(function (a, b) { return b.colheita.localeCompare(a.colheita); }).slice(0, n); }
  function urlLote(cod) {
    if (D.config.urlLote) return D.config.urlLote.replace("{codigo}", encodeURIComponent(cod));
    var base = location.href.split("#")[0].split("?")[0].replace(/[^\/]*$/, "");
    return base + "lote.html#" + cod;
  }
  function hashParam(fallbackKey) {
    var h = decodeURIComponent((location.hash || "").replace(/^#/, ""));
    if (h) return h;
    try { return new URLSearchParams(location.search).get(fallbackKey) || ""; } catch (e) { return ""; }
  }

  // Aceita "panc 2026 3", "PANC-2026-0003", "panc20260003"...
  function normalizarCodigo(txt) {
    var m = String(txt || "").toUpperCase().match(/PANC\D*(\d{4})\D*(\d{1,4})\b/);
    if (!m) return null;
    return "PANC-" + m[1] + "-" + ("000" + m[2]).slice(-4);
  }

  function qrSvg(texto, titulo) {
    if (typeof window.qrcode !== "function") return '<span class="source">QR Code indisponível</span>';
    var q = window.qrcode(0, "M");
    q.addData(texto);
    q.make();
    return q.createSvgTag({ cellSize: 4, margin: 0, scalable: true, title: titulo || "QR Code do lote" });
  }

  function folhaSvg() {
    return '<svg viewBox="0 0 200 150" aria-hidden="true" preserveAspectRatio="xMidYMid slice"><g fill="none" stroke="currentColor" stroke-width="2.2">' +
      '<path d="M20 130 C60 60 120 40 180 20 C150 80 100 120 20 130Z"/><path d="M20 130 C80 100 130 60 180 20"/>' +
      '<path d="M60 110 l10 -22 M90 96 l6 -26 M120 78 l2 -24 M150 54 l-2 -18"/></g></svg>';
  }

  // Imagem com fallback ilustrado (quando a foto não carrega).
  function media(esp, extraClass, badge) {
    var src = esp.imagem || "";
    return '<div class="media ' + (extraClass || "") + '" style="--ph:' + esc(esp.cor || "") + '">' +
      '<div class="ph">' + folhaSvg() + '<span>' + esc(esp.nome) + '</span></div>' +
      (src ? '<img src="' + esc(src) + '" alt="' + esc(esp.nome + " (" + esp.cientifico + ")") + '" loading="lazy" onerror="this.remove()">' : "") +
      (badge || "") + '</div>';
  }

  function toast(msg) {
    var t = document.createElement("div");
    t.className = "toast"; t.setAttribute("role", "status"); t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function copiar(texto, ok) {
    var done = function () { toast(ok || "Copiado"); };
    var falhou = function () { toast("Não foi possível copiar. Endereço: " + texto); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(done, falhou);
    } else { falhou(); }
  }

  /* ---------- Componentes ---------- */
  function cardEspecie(e) {
    var n = lotesDe(e.id).length;
    var tags = '<span class="chip ' + (categoria(e) === "Flor alimentícia" ? "chip-wine" : categoria(e) === "TENC" ? "chip-gold" : "chip-leaf") + ' tag">' + esc(categoria(e)) + '</span>' +
      (completa(e) ? '<span class="chip chip-wine tag2">Ficha completa</span>' : "");
    return '<a class="card" href="planta.html#' + e.id + '">' + media(e, "", tags) +
      '<div class="card-body"><span class="family">' + esc(e.familia) + '</span>' +
      '<h3>' + esc(e.nome) + '</h3><span class="sci">' + esc(e.cientifico) + '</span>' +
      '<p>' + esc(e.resumo) + '</p></div>' +
      '<div class="card-meta"><span>' + esc(e.partes.join(" · ")) + '</span><span class="chip chip-leaf">' + n + (n === 1 ? " lote" : " lotes") + '</span></div></a>';
  }

  function linhaLote(l) {
    var e = especie(l.especie) || { nome: l.especie, cientifico: "", cor: "" };
    return '<a class="lot" href="lote.html#' + l.codigo + '">' + media(e) +
      '<div class="lot-main"><h3>' + esc(e.nome) + (l.categoria && l.categoria !== "In natura" ? ' <span class="chip chip-gold">' + esc(l.categoria) + '</span>' : "") + '</h3>' +
      '<span class="sub">' + esc(l._p.nome) + ' · ' + esc(l._p.municipio) + '/' + esc(l._p.uf) + '</span>' +
      '<div class="chips"><span class="chip chip-leaf">' + esc(l.metodo) + '</span>' + (l.teste ? '<span class="chip">Registro de teste</span>' : "") + '</div></div>' +
      '<div class="lot-side"><span class="code-tag">' + esc(l.codigo) + '</span><span>Colhido em <time datetime="' + l.colheita + '">' + fmtData(l.colheita) + '</time></span></div></a>';
  }

  function etiquetaHtml(l) {
    var e = especie(l.especie);
    return '<article class="etiqueta" aria-label="Etiqueta do lote ' + esc(l.codigo) + '">' +
      '<div class="et-info"><span class="et-kicker"><img src="assets/img/icone.svg" width="14" height="14" alt="" style="vertical-align:-2px">Lote rastreado · PANCverso</span>' +
      '<span class="et-nome">' + esc(e.nome) + '</span><span class="et-sci">' + esc(e.cientifico) + '</span>' +
      '<dl><dt>Local</dt><dd>' + esc(l._p.municipio + "/" + l._p.uf) + '</dd>' +
      '<dt>Colheita</dt><dd>' + fmtData(l.colheita) + '</dd>' +
      '<dt>Método</dt><dd>' + esc(l.metodo) + '</dd>' +
      '<dt>Lote</dt><dd class="et-code">' + esc(l.codigo) + '</dd></dl></div>' +
      '<div class="et-qr">' + qrSvg(urlLote(l.codigo), "QR Code do lote " + l.codigo) + '<span>Aponte a câmera</span></div>' +
      '<div class="et-foot"><b>Universidade de Vassouras<br>Mestrado Profissional em Ciências Ambientais</b><span>Escaneie e conheça a origem</span></div></article>';
  }

  function nutricaoHtml(e) {
    var n = e.nutricao;
    return '<div class="stack"><p><strong>Parte analisada e base:</strong> ' + esc(n.parte) + ' · valores por 100 g</p>' +
      '<div class="table-wrap"><table><caption class="sr-only">Composição de ' + esc(e.nome) + '</caption><thead><tr><th scope="col">Componente</th><th scope="col">Teor (por 100 g)</th></tr></thead><tbody>' +
      n.itens.map(function (i) { return '<tr><td>' + esc(i[0]) + '</td><td class="num">' + esc(i[1]) + '</td></tr>'; }).join("") +
      '</tbody></table></div>' + (n.nota ? '<p>' + esc(n.nota) + '</p>' : "") +
      '<p class="source">Fonte: ' + esc(n.fonte) + '. Os valores variam conforme cultivar, solo, adubação, época de colheita e método de análise, e servem como referência. Valores em massa seca e em massa fresca não são comparáveis entre si. Esta ficha descreve a composição e não faz alegações de efeitos sobre a saúde.</p></div>';
  }

  var HIGIENIZACAO = '<ol class="stack" style="padding-left:1.2em;gap:6px"><li>Lave as folhas em água corrente, retirando terra e partes estragadas.</li>' +
    '<li>Deixe de molho por 10 minutos em 1 litro de água com 1 colher (sopa) de água sanitária própria para alimentos (ou o produto indicado no rótulo).</li>' +
    '<li>Enxágue em água corrente e seque antes de guardar ou preparar.</li></ol>';

  function receitasHtml(e) {
    return '<div class="recipes">' + e.receitas.map(function (r) {
      return '<article class="recipe"><div><h3>' + esc(r.titulo) + '</h3><span class="source">' + esc(r.rende) + '</span></div>' +
        '<div><h4>Ingredientes</h4><ul>' + r.ingredientes.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join("") + '</ul></div>' +
        '<div><h4>Modo de preparo</h4><ol>' + r.modo.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join("") + '</ol></div></article>';
    }).join("") + '</div><p class="source">Receitas organizadas a partir dos usos culinários descritos em Kinupp e Lorenzi (2014), Brasil/MAPA (2010) e Embrapa Hortaliças (2017).</p>';
  }

  function cuidadosHtml(e) {
    return '<div class="notice" role="note">' + ICON.alert + '<div><p><strong>Cuidados com ' + esc(e.nome) + '</strong></p>' +
      e.cuidados.map(function (c) { return '<p>' + esc(c) + '</p>'; }).join("") + '</div></div>' +
      '<p><strong>Como reconhecer:</strong> ' + esc(e.identificacao) + '</p>';
  }

  function tabs(root) {
    var list = $('[role="tablist"]', root);
    var tabsEls = $$('[role="tab"]', list);
    function select(t, focus) {
      tabsEls.forEach(function (x) {
        var on = x === t;
        x.setAttribute("aria-selected", on); x.tabIndex = on ? 0 : -1;
        document.getElementById(x.getAttribute("aria-controls")).hidden = !on;
      });
      if (focus) t.focus();
    }
    tabsEls.forEach(function (t, i) {
      t.addEventListener("click", function () { select(t); });
      t.addEventListener("keydown", function (ev) {
        var k = ev.key, n = tabsEls.length, j = null;
        if (k === "ArrowRight") j = (i + 1) % n; else if (k === "ArrowLeft") j = (i - 1 + n) % n;
        else if (k === "Home") j = 0; else if (k === "End") j = n - 1;
        if (j !== null) { ev.preventDefault(); select(tabsEls[j], true); }
      });
    });
    select(tabsEls[0]);
  }

  var ICON = {
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" width="20" height="20"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/></svg>',
    flower: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" width="20" height="20"><circle cx="12" cy="12" r="2.5"/><path d="M12 9.5C10 6 10 3 12 3s2 3 0 6.5zM12 14.5c2 3.5 2 6.5 0 6.5s-2-3 0-6.5zM9.5 12C6 10 3 10 3 12s3 2 6.5 0zM14.5 12c3.5 2 6.5 2 6.5 0s-3-2-6.5 0z"/></svg>',
    leaf: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" width="20" height="20"><path d="M20 4C10 4 4 9 4 16c0 1.5.4 2.8 1 4 1-6 5-10 11-12-5 3-8 7-8 12 8 0 12-7 12-16z"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 5v14l12-7z"/></svg>',
    flame: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" width="18" height="18" style="vertical-align:-3px"><path d="M12 2s5 4.5 5 10a5 5 0 01-10 0c0-2 1-3.5 1-3.5S9 11 10.5 11C10.5 7 12 2 12 2z"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2l2.4 2.1 3.2-.3.9 3.1 2.8 1.6-1 3 1 3-2.8 1.6-.9 3.1-3.2-.3L12 22l-2.4-2.1-3.2.3-.9-3.1L2.7 15.5l1-3-1-3 2.8-1.6.9-3.1 3.2.3z"/><path d="M8.5 12.5l2.3 2.3 4.7-5"/></svg>'
  };

  /* ---------- Comuns a todas as páginas ---------- */
  function comum() {
    var btn = $(".nav-toggle"), nav = $("#menu");
    if (btn && nav) {
      btn.addEventListener("click", function () {
        var open = nav.classList.toggle("open");
        btn.setAttribute("aria-expanded", open);
      });
    }
    $$(".logos img").forEach(function (img) {
      img.addEventListener("error", function () {
        var s = document.createElement("span"); s.className = "logo-txt"; s.textContent = img.alt;
        img.replaceWith(s);
      });
      if (img.complete && img.naturalWidth === 0) img.dispatchEvent(new Event("error"));
    });
    $$("[data-copy]").forEach(function (b) {
      b.addEventListener("click", function () { copiar(b.getAttribute("data-copy"), b.getAttribute("data-ok") || "Copiado"); });
    });
    $$("form.lookup-form").forEach(function (f) {
      f.addEventListener("submit", function (ev) {
        ev.preventDefault();
        var inp = $("input", f), err = $(".field-error", f);
        var cod = normalizarCodigo(inp.value);
        if (!cod) { err.hidden = false; err.textContent = "Digite o código como aparece na etiqueta, por exemplo PANC-2026-0003."; inp.setAttribute("aria-invalid", "true"); inp.focus(); return; }
        location.href = "lote.html#" + cod;
      });
    });
    var y = $("#ano"); if (y) y.textContent = new Date().getFullYear();
    whatsapp();
  }

  /* Caixa flutuante de contato: abre o WhatsApp (número em config.whatsapp). */
  function whatsapp() {
    var box = $("#wa-float"), btn = $("#wa-btn"), pn = $("#wa-panel"), f = $("#wa-form");
    if (!box) return;
    if (!D.config.whatsapp || /painel|login/.test(document.body.getAttribute("data-page"))) { box.hidden = true; return; }
    function abrir(on) {
      pn.hidden = !on; btn.setAttribute("aria-expanded", on); box.classList.toggle("aberto", on);
      if (on) setTimeout(function () { $("#wa-msg").focus(); }, 30); else btn.focus();
    }
    btn.addEventListener("click", function () { abrir(pn.hidden); });
    $("#wa-fechar").addEventListener("click", function () { abrir(false); });
    document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && !pn.hidden) abrir(false); });
    $$("[data-wa-abrir]").forEach(function (b) { b.addEventListener("click", function () { abrir(true); }); });
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var msg = $("#wa-msg").value.trim(), nome = $("#wa-nome").value.trim(), err = $("#wa-erro");
      if (!msg) { err.hidden = false; $("#wa-msg").setAttribute("aria-invalid", "true"); $("#wa-msg").focus(); return; }
      err.hidden = true; $("#wa-msg").removeAttribute("aria-invalid");
      var texto = (nome ? "Olá! Sou " + nome + ". " : "Olá! ") + msg + "\n\n(Enviado pelo site PANCverso: " + document.title + ")";
      window.open("https://wa.me/" + D.config.whatsapp + "?text=" + encodeURIComponent(texto), "_blank", "noopener");
    });
  }

  /* ---------- Páginas ---------- */
  var PAGES = {};

  function ticker() {
    var box = $("#ticker"), track = $("#ticker-track"); if (!box || !track || !D.noticias) return;
    var CLS = { "Novidade": "t-novidade", "Atualização": "t-atualizacao" };
    var itens = D.noticias.map(function (n) {
      var txt = esc(n.texto.replace("{especies}", D.especies.length));
      return '<li class="ticker-item"><span class="ticker-tag ' + (CLS[n.tipo] || "") + '">' + esc(n.tipo) + '</span>' + (n.link ? '<a href="' + esc(n.link) + '">' + txt + '</a>' : '<span>' + txt + '</span>') + '</li>';
    }).join("");
    track.innerHTML = '<ul>' + itens + '</ul><ul aria-hidden="true">' + itens.replace(/<a /g, '<a tabindex="-1" ') + '</ul>';
    var chars = D.noticias.reduce(function (t, n) { return t + n.texto.length + 14; }, 0);
    track.style.setProperty("--dur", Math.round(chars * 0.16) + "s");
    var b = $("#ticker-btn");
    if (b) b.addEventListener("click", function () {
      var parado = box.classList.toggle("parado");
      b.setAttribute("aria-pressed", parado);
      b.innerHTML = parado ? ICON.play + '<span class="txt">Continuar</span>' : ICON.pause + '<span class="txt">Pausar</span>';
    });
  }

  PAGES.inicio = function () {
    ticker();
    $("#hero-label").innerHTML = etiquetaHtml(lote("PANC-2026-0003") || LOTES[0]);
    $("#home-catalogo").innerHTML = D.especies.filter(completa).map(cardEspecie).join("");
    var nc = $("#n-especies"); if (nc) nc.textContent = D.especies.length;
    $("#home-lotes").innerHTML = recentes(3).map(linhaLote).join("");
  };

  PAGES.catalogo = function () {
    var grid = $("#catalogo"), busca = $("#busca"), parte = $("#parte"), count = $("#count"), seg = $("#cat-seg");
    var GRUPOS = [["", "Todas"], ["completa", "Fichas completas"], ["PANC", "PANC"], ["Flor alimentícia", "Flores"], ["TENC", "Temperos (TENC)"], ["Parte não convencional", "Partes não convencionais"], ["lotes", "Com lotes"]];
    function noGrupo(e, g) { return !g || (g === "completa" ? completa(e) : g === "lotes" ? lotesDe(e.id).length > 0 : categoria(e) === g); }
    var grupo = "";
    var h = (location.hash || "").replace("#", "");
    var mapa = { flores: "Flor alimentícia", tenc: "TENC", partes: "Parte não convencional", panc: "PANC", completas: "completa", lotes: "lotes" };
    if (mapa[h]) grupo = mapa[h];
    seg.innerHTML = GRUPOS.map(function (g) {
      var n = D.especies.filter(function (e) { return noGrupo(e, g[0]); }).length;
      return '<button type="button" data-g="' + esc(g[0]) + '" aria-pressed="' + (g[0] === grupo) + '">' + esc(g[1]) + '<span class="n">' + n + '</span></button>';
    }).join("");
    var partes = {};
    D.especies.forEach(function (e) { e.partes.forEach(function (p) { partes[p.split(" (")[0]] = 1; }); });
    parte.innerHTML += Object.keys(partes).sort().map(function (p) { return '<option>' + esc(p) + '</option>'; }).join("");
    function render() {
      var q = busca.value.trim().toLowerCase(), p = parte.value;
      var list = D.especies.filter(function (e) {
        var txt = [e.nome, e.cientifico, e.familia, e.resumo, e.uso || "", e.usos.join(" ")].join(" ").toLowerCase();
        return noGrupo(e, grupo) && (!q || txt.indexOf(q) > -1) && (!p || e.partes.some(function (x) { return x.indexOf(p) === 0; }));
      }).sort(function (a, b) { return (completa(b) - completa(a)) || a.nome.localeCompare(b.nome, "pt"); });
      count.textContent = list.length + (list.length === 1 ? " espécie" : " espécies");
      grid.innerHTML = list.length ? list.map(cardEspecie).join("") : '<div class="empty">Nenhuma espécie encontrada. Tente outro termo ou outro grupo.</div>';
    }
    $$("button", seg).forEach(function (b) {
      b.addEventListener("click", function () {
        grupo = b.getAttribute("data-g");
        $$("button", seg).forEach(function (x) { x.setAttribute("aria-pressed", x === b); });
        render();
      });
    });
    busca.addEventListener("input", render); parte.addEventListener("change", render);
    var t = $("#tenc"); if (t && D.tenc) t.innerHTML = D.tenc.map(function (n) {
      var e = D.especies.find(function (x) { return x.nome.toLowerCase() === n.toLowerCase(); });
      return e ? '<a class="chip chip-gold" href="planta.html#' + e.id + '">' + esc(n) + '</a>' : '<span class="chip">' + esc(n) + '</span>';
    }).join("");
    render();
  };

  function usoGuiaHtml(e) {
    return '<div class="panel stack"><h3>Na cozinha</h3><p>' + esc(e.uso) + '</p></div>' +
      (e.atencao ? '<div class="notice" role="note">' + ICON.alert + '<div><p><strong>Atenção</strong></p><p>' + esc(e.atencao) + '</p></div></div>' : "") +
      '<div class="notice notice-wine" role="note">' + ICON.info + '<div><p><strong>Na dúvida, não coma.</strong> Confira a planta inteira (folhas, flores e, se possível, raízes) em fontes seguras, colha longe de calçadas e locais poluídos e consuma só flores cultivadas para alimentação.</p></div></div>' +
      '<p class="source">Fonte: Programa CapacitAgro. <em>Capacitação em PANC: plantas alimentícias não convencionais</em>. Niterói: PESAGRO-RIO, 2024. Texto adaptado.</p>';
  }

  PAGES.planta = function () {
    function render() {
      var id = hashParam("p") || "ora-pro-nobis";
      var e = especie(id);
      var root = $("#planta");
      if (!e) { root.innerHTML = '<div class="empty"><h1>Espécie não encontrada</h1><p style="margin-top:8px">Veja as espécies disponíveis no <a href="catalogo.html">catálogo</a>.</p></div>'; return; }
      document.title = e.nome + " (" + e.cientifico.split(" ").slice(0, 2).join(" ") + ") · PANCverso";
      var ls = lotesDe(e.id);
      var outras = D.especies.filter(function (x) { return x.id !== e.id && categoria(x) === categoria(e); });
      outras = outras.sort(function (a, b) { return (completa(b) - completa(a)) || a.nome.localeCompare(b.nome); }).slice(0, 4);
      var head =
        '<nav class="breadcrumb" aria-label="Você está em"><a href="catalogo.html">Catálogo</a> / ' + esc(e.nome) + '</nav>' +
        '<div class="plant-hero"><figure style="margin:0;display:grid;gap:6px">' + media(e) + creditoHtml(e) + '</figure>' +
        '<div class="stack"><span class="family">' + esc(e.familia) + ' · ' + esc(e.origem) + '</span><h1>' + esc(e.nome) + '</h1>' +
        '<p class="sci" style="font-size:1.2rem">' + esc(e.cientifico) + '</p><p class="lead">' + esc(e.descricao || e.resumo) + '</p>' +
        '<div class="chips"><span class="chip chip-leaf">' + esc(categoria(e)) + '</span>' + (completa(e) ? '<span class="chip chip-wine">Ficha completa</span>' : '<span class="chip">Guia CapacitAgro (2024)</span>') + '</div>' +
        '<dl class="quick">' + (e.sabor ? '<div><dt>Sabor</dt><dd>' + esc(e.sabor) + '</dd></div>' : "") +
        '<div><dt>Partes comestíveis</dt><dd>' + esc(e.partes.join(", ")) + '</dd></div>' +
        '<div><dt>Usos</dt><dd>' + esc(e.usos.join(", ")) + '</dd></div>' +
        (e.propagacao ? '<div><dt>Propagação</dt><dd>' + esc(e.propagacao) + '</dd></div>' : "") +
        '<div><dt>Lotes rastreados</dt><dd>' + ls.length + '</dd></div></dl></div></div>';
      var corpo = completa(e) ?
        '<div class="tabs" style="margin-top:40px"><div role="tablist" aria-label="Informações sobre ' + esc(e.nome) + '">' +
        '<button role="tab" id="t-preparo" aria-controls="p-preparo">Preparo e cuidados</button>' +
        '<button role="tab" id="t-receitas" aria-controls="p-receitas">Receitas</button>' +
        '<button role="tab" id="t-nutri" aria-controls="p-nutri">Nutricional</button>' +
        '<button role="tab" id="t-lotes" aria-controls="p-lotes">Lotes (' + ls.length + ')</button></div>' +
        '<section role="tabpanel" id="p-preparo" aria-labelledby="t-preparo" tabindex="0"><div class="two-col"><div class="stack"><h2 class="sr-only">Preparo</h2><ul class="checklist">' + e.preparo.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join("") + '</ul>' +
        '<div class="panel" style="margin-top:8px"><h3>Como higienizar folhas e flores</h3>' + HIGIENIZACAO + '</div></div><div class="stack">' + cuidadosHtml(e) + '</div></div></section>' +
        '<section role="tabpanel" id="p-receitas" aria-labelledby="t-receitas" tabindex="0" hidden>' + receitasHtml(e) + '</section>' +
        '<section role="tabpanel" id="p-nutri" aria-labelledby="t-nutri" tabindex="0" hidden>' + nutricaoHtml(e) + '</section>' +
        '<section role="tabpanel" id="p-lotes" aria-labelledby="t-lotes" tabindex="0" hidden><div class="lot-list">' + (ls.length ? ls.map(linhaLote).join("") : '<div class="empty">Ainda não há lotes desta espécie.</div>') + '</div></section></div>'
        :
        '<div class="two-col" style="margin-top:40px"><div class="stack">' + usoGuiaHtml(e) + '</div>' +
        '<div class="stack"><div class="panel"><h3>Como higienizar folhas e flores</h3>' + HIGIENIZACAO + '</div>' +
        '<section class="panel"><h3>Lotes rastreados (' + ls.length + ')</h3>' + (ls.length ? '<div class="lot-list">' + ls.map(linhaLote).join("") + '</div>' : '<p class="source">Ainda não há lotes desta espécie. A ficha completa, com receitas e informação nutricional, será publicada quando a espécie entrar no teste piloto.</p>') + '</section></div></div>';
      root.innerHTML = head + corpo +
        '<section style="margin-top:56px"><div class="section-head"><h2 style="font-size:1.5rem">Outras espécies: ' + esc(categoria(e)) + '</h2><a class="btn btn-ghost btn-sm" href="catalogo.html">Ver o catálogo</a></div><div class="grid-cards">' +
        outras.map(cardEspecie).join("") + '</div></section>';
      if (completa(e)) tabs($(".tabs", root));
      window.scrollTo(0, 0);
    }
    window.addEventListener("hashchange", render);
    render();
  };

  PAGES.lotes = function () {
    var fEsp = $("#f-especie"), fMun = $("#f-municipio"), fMet = $("#f-metodo"), busca = $("#f-busca");
    var opts = function (arr) { return arr.map(function (v) { return '<option value="' + esc(v[0]) + '">' + esc(v[1]) + '</option>'; }).join(""); };
    var uniq = function (arr) { return arr.filter(function (v, i) { return arr.indexOf(v) === i; }).sort(); };
    fEsp.innerHTML += opts(D.especies.filter(function (e) { return lotesDe(e.id).length; }).map(function (e) { return [e.id, e.nome]; }));
    fMun.innerHTML += opts(uniq(LOTES.map(function (l) { return l._p.municipio + "/" + l._p.uf; })).map(function (m) { return [m, m]; }));
    fMet.innerHTML += opts(uniq(LOTES.map(function (l) { return l.metodo; })).map(function (m) { return [m, m]; }));
    var pre = hashParam("especie"); if (pre && especie(pre)) fEsp.value = pre;
    function render() {
      var q = busca.value.trim().toLowerCase();
      var list = LOTES.filter(function (l) {
        var e = especie(l.especie) || {};
        var txt = [l.codigo, e.nome, e.cientifico, l._p.nome, l._p.municipio].join(" ").toLowerCase();
        return (!fEsp.value || l.especie === fEsp.value) && (!fMun.value || (l._p.municipio + "/" + l._p.uf) === fMun.value) &&
          (!fMet.value || l.metodo === fMet.value) && (!q || txt.indexOf(q) > -1);
      }).sort(function (a, b) { return b.colheita.localeCompare(a.colheita); });
      $("#count").textContent = list.length + (list.length === 1 ? " lote encontrado" : " lotes encontrados");
      $("#lista").innerHTML = list.length ? list.map(linhaLote).join("") : '<div class="empty">Nenhum lote corresponde aos filtros. <button class="btn btn-ghost btn-sm" type="button" id="limpar">Limpar filtros</button></div>';
      var c = $("#limpar"); if (c) c.addEventListener("click", function () { fEsp.value = fMun.value = fMet.value = ""; busca.value = ""; render(); });
    }
    [fEsp, fMun, fMet].forEach(function (s) { s.addEventListener("change", render); });
    busca.addEventListener("input", render);
    render();
  };

  PAGES.lote = function () {
    function render() {
      var cod = normalizarCodigo(hashParam("c")) || hashParam("c");
      var l = lote(cod), root = $("#lote");
      if (!l) {
        document.title = "Lote não encontrado · PANCverso";
        root.innerHTML = '<div class="panel" style="max-width:640px;margin:0 auto"><span class="eyebrow">Consulta de lote</span><h1 style="font-size:2rem">Lote não encontrado</h1>' +
          '<p>' + (cod ? 'Não encontramos o lote <span class="code-tag">' + esc(cod) + '</span>.' : 'Nenhum código foi informado.') + ' Confira o código impresso na etiqueta, abaixo do QR Code, e digite de novo.</p>' +
          '<form class="lookup-form" novalidate><label for="cod2" style="font-weight:700">Código do lote</label><div class="lookup-row" style="margin-top:8px"><input id="cod2" type="text" inputmode="text" autocomplete="off" placeholder="PANC-2026-0003" value="' + esc(cod || "") + '"><button class="btn btn-primary" type="submit">Consultar</button></div><p class="field-error" hidden></p></form>' +
          '<p class="source">Lotes arquivados deixam de aparecer publicamente. Se o problema continuar, fale com a gente pelo WhatsApp ' + esc(D.config.telefoneExibicao) + '.</p>' +
          '<div class="btn-row"><a class="btn btn-ghost" href="lotes.html">Ver todos os lotes</a><a class="btn btn-ghost" href="catalogo.html">Conhecer o catálogo</a></div></div>';
        comumLookup(root);
        return;
      }
      var e = especie(l.especie), p = l._p;
      document.title = "Lote " + l.codigo + " · " + e.nome + " · PANCverso";
      var url = urlLote(l.codigo);
      var loc = lerLocal(); loc.acessos[l.codigo] = (loc.acessos[l.codigo] || 0) + 1; gravarLocal(loc);
      root.innerHTML =
        (l.teste ? '<div class="notice" role="note" style="margin-bottom:24px">' + ICON.info + '<div><p><strong>Registro de teste.</strong> Este lote foi cadastrado para verificar o funcionamento do sistema. Os lotes dos produtores participantes serão publicados durante o teste piloto, após aprovação do Comitê de Ética em Pesquisa.</p></div></div>' : "") +
        '<div class="ficha-head"><div class="stack"><span class="seal">' + ICON.check + 'Lote rastreado</span>' +
        '<h1>' + esc(e.nome) + '</h1><p class="sci" style="font-size:1.2rem;margin-top:-6px">' + esc(e.cientifico) + ' · ' + esc(e.familia) + '</p>' +
        '<p><span class="code-tag" style="font-size:1rem">' + esc(l.codigo) + '</span></p></div>' +
        '<div class="qr-box">' + qrSvg(url, "QR Code desta ficha") + '<span>Mostre este código para outra pessoa abrir a ficha</span></div></div>' +
        (l.foto ? '<figure style="margin:28px 0 0"><img src="' + esc(l.foto) + '" alt="Foto do lote ' + esc(l.codigo) + '" style="width:100%;max-height:420px;object-fit:cover;border-radius:var(--radius)"></figure>' : "") +
        '<dl class="facts" style="margin-top:28px">' +
        fact("Colheita", fmtData(l.colheita)) + fact("Município", p.municipio + "/" + p.uf) + fact("Método de cultivo", l.metodo) +
        fact("Origem", l.origem) + fact("Início do cultivo/coleta", fmtData(l.inicio)) + fact("Peso colhido", fmtKg(l.pesoKg)) + '</dl>' +
        '<div class="two-col" style="margin-top:28px">' +
        '<div class="stack">' +
        '<section class="panel"><h2>Quem produziu</h2><dl class="kv"><dt>Produtor</dt><dd>' + esc(p.nome) + '</dd><dt>Propriedade</dt><dd>' + esc(p.propriedade) + '</dd><dt>Tipo</dt><dd>' + esc(p.tipo) + '</dd></dl>' + (p.historia ? '<p>' + esc(p.historia) + '</p>' : "") + (p.consentimento !== false && p.id ? '<a href="produtores.html#' + esc(p.id) + '">Ver todos os lotes deste produtor</a>' : "") + '</section>' +
        '<section class="panel"><h2>Manejo</h2><dl class="kv"><dt>Adubação</dt><dd>' + esc(l.manejo.adubacao) + '</dd><dt>Irrigação</dt><dd>' + esc(l.manejo.irrigacao) + '</dd><dt>Controle de pragas</dt><dd>' + esc(l.manejo.pragas) + '</dd></dl></section>' +
        '<section class="panel"><h2>Processamento e produto</h2><dl class="kv"><dt>Parte utilizada</dt><dd>' + esc(l.partes.join(", ")) + '</dd><dt>Processamento</dt><dd>' + esc(l.processamento) + '</dd><dt>Categoria</dt><dd>' + esc(l.categoria) + '</dd><dt>Bom para</dt><dd><div class="chips">' + l.preparos.map(function (x) { return '<span class="chip chip-leaf">' + esc(x) + '</span>'; }).join("") + '</div></dd>' +
        (l.ingredientes ? '<dt>Ingredientes e uso</dt><dd>' + esc(l.ingredientes) + '</dd>' : "") + '</dl></section></div>' +
        '<aside class="stack">' +
        '<section class="panel"><h2>Caminho do lote</h2><ol class="timeline">' +
        '<li><div><time datetime="' + l.inicio + '">' + fmtData(l.inicio) + '</time><strong>Início do ' + (/coleta/i.test(l.origem) ? "processo de coleta" : "cultivo") + '</strong><span class="source">' + esc(p.propriedade) + '</span></div></li>' +
        '<li><div><time datetime="' + l.colheita + '">' + fmtData(l.colheita) + '</time><strong>Colheita</strong><span class="source">' + fmtKg(l.pesoKg) + ' · ' + esc(l.partes.join(", ").toLowerCase()) + '</span></div></li>' +
        '<li><div><strong>Processamento</strong><span class="source">' + esc(l.processamento) + '</span></div></li>' +
        '<li><div><strong>Etiqueta com QR Code</strong><span class="source">Código ' + esc(l.codigo) + ' gerado na plataforma</span></div></li></ol></section>' +
        '<section class="panel"><h2>Sua opinião</h2><p>Você comprou este produto? Conte como foi a experiência de consultar a ficha. Leva cerca de 5 minutos e é anônimo.</p><a class="btn btn-primary" href="avaliar.html#' + esc(l.codigo) + '">Avalie esta experiência</a></section>' +
        '<div class="notice notice-leaf" role="note">' + ICON.lock + '<div><p><strong>Privacidade do produtor.</strong> Telefone, endereço completo e localização exata da propriedade não são publicados, conforme a LGPD (Lei nº 13.709/2018). Aqui aparece só o município.</p></div></div>' +
        '<div class="btn-row"><button class="btn btn-ghost btn-sm" type="button" data-copy="' + esc(url) + '" data-ok="Link do lote copiado">Copiar link do lote</button></div>' +
        '</aside></div>' +
        '<section style="margin-top:56px" class="stack-lg"><div class="section-head"><div class="stack"><span class="eyebrow">Sobre a espécie</span><h2>Como usar ' + esc(e.nome.toLowerCase()) + '</h2></div><a class="btn btn-ghost" href="planta.html#' + e.id + '">Ficha completa da espécie</a></div>' +
        (completa(e) ? '<div class="two-col"><div class="stack">' + cuidadosHtml(e) + '<div class="panel"><h3>Como higienizar</h3>' + HIGIENIZACAO + '</div></div><div class="panel"><h3>Valor nutricional</h3>' + nutricaoHtml(e) + '</div></div>' +
        receitasHtml(e) : '<div class="two-col"><div class="stack">' + usoGuiaHtml(e) + '</div><div class="panel"><h3>Como higienizar</h3>' + HIGIENIZACAO + '</div></div>') + '</section>';
      $$("[data-copy]", root).forEach(function (b) { b.addEventListener("click", function () { copiar(b.getAttribute("data-copy"), b.getAttribute("data-ok")); }); });
      window.scrollTo(0, 0);
    }
    function fact(k, v) { return '<div><dt>' + esc(k) + '</dt><dd>' + esc(v) + '</dd></div>'; }
    function comumLookup(root) {
      $$("form.lookup-form", root).forEach(function (f) {
        f.addEventListener("submit", function (ev) {
          ev.preventDefault();
          var inp = $("input", f), err = $(".field-error", f), c = normalizarCodigo(inp.value);
          if (!c) { err.hidden = false; err.textContent = "Digite o código como aparece na etiqueta, por exemplo PANC-2026-0003."; inp.setAttribute("aria-invalid", "true"); inp.focus(); return; }
          location.hash = c;
        });
      });
    }
    window.addEventListener("hashchange", render);
    render();
  };

  function creditoHtml(e) {
    var c = e.credito; if (!c) return "";
    return '<figcaption class="source">Foto: ' + esc(c.autor) + ' · <a href="' + esc(c.licencaUrl || c.fonte) + '" rel="noopener">' + esc(c.licenca) + '</a> · <a href="' + esc(c.fonte) + '" rel="noopener">Wikimedia Commons</a></figcaption>';
  }

  PAGES.sobre = function () {
    var el = $("#creditos"); if (!el) return;
    function li(nome, c) {
      return '<li><strong>' + esc(nome) + ':</strong> “' + esc(c.titulo) + '”, de ' + esc(c.autor) + '. Licença <a href="' + esc(c.licencaUrl || c.fonte) + '" rel="noopener">' + esc(c.licenca) + '</a>. Disponível em: <a href="' + esc(c.fonte) + '" rel="noopener">Wikimedia Commons</a>.' + (c.alteracoes ? ' ' + esc(c.alteracoes) : "") + '</li>';
    }
    el.innerHTML = D.especies.filter(function (e) { return e.credito; }).map(function (e) { return li(e.nome, e.credito); }).join("") +
      todosProdutores().filter(function (p) { return p.fotoCredito; }).map(function (p) { return li("Foto ilustrativa de " + p.nome, p.fotoCredito); }).join("");
  };

  function fotoProdutor(p, cls) {
    var ini = esc((p.nome || "?").split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase());
    return '<div class="media ' + (cls || "") + '" style="aspect-ratio:auto;position:absolute;inset:0"><div class="ph"><span>' + ini + '</span></div>' +
      (p.foto ? '<img src="' + esc(p.foto) + '" alt="Foto da propriedade: ' + esc(p.propriedade || p.nome) + '" loading="lazy" onerror="this.remove()" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">' : "") + '</div>';
  }
  function creditoProdutor(p) {
    var c = p.fotoCredito;
    var pre = p.simulado || p.teste ? "Foto ilustrativa" : "Foto";
    if (!c) return p.foto && (p.simulado || p.teste) ? '<p class="foto-credito">' + pre + '.</p>' : "";
    return '<p class="foto-credito">' + pre + ': ' + esc(c.autor) + ' · <a href="' + esc(c.licencaUrl || c.fonte) + '" rel="noopener">' + esc(c.licenca) + '</a> · <a href="' + esc(c.fonte) + '" rel="noopener">Wikimedia Commons</a></p>';
  }
  function lotesDoProdutor(id) { return LOTES.filter(function (l) { return l.produtor === id; }).sort(function (a, b) { return b.colheita.localeCompare(a.colheita); }); }
  function especiesDoProdutor(id) { return lotesDoProdutor(id).map(function (l) { return l.especie; }).filter(function (v, i, a) { return a.indexOf(v) === i; }); }
  function cardProdutor(p) {
    var ls = lotesDoProdutor(p.id), esps = especiesDoProdutor(p.id);
    return '<a class="prod-card" href="produtores.html#' + esc(p.id) + '"><div class="prod-thumb">' + fotoProdutor(p) +
      (p.simulado ? '<span class="chip chip-sim badge">Produtor simulado</span>' : p.teste ? '<span class="chip chip-sim badge">Registro de teste</span>' : "") +
      '<div class="over"><strong>' + esc(p.nome) + '</strong><span>' + esc(p.municipio) + '/' + esc(p.uf) + ' · ' + esc(p.tipo) + '</span></div></div>' +
      '<div class="prod-body"><div class="chips">' + (p.sistema && p.sistema !== "—" ? '<span class="chip chip-leaf">' + esc(p.sistema) + '</span>' : "") +
      '<span class="chip chip-wine">' + ls.length + (ls.length === 1 ? " lote" : " lotes") + '</span></div>' +
      (esps.length ? '<p>' + esc(esps.map(function (id) { var e = especie(id); return e ? e.nome : id; }).join(", ")) + '</p>' : '<p>Ainda sem lotes publicados.</p>') + '</div></a>';
  }

  PAGES.produtores = function () {
    var root = $("#produtores"), intro = $("#prod-intro"), avisos = $("#prod-avisos");
    function render() {
      var alvo = hashParam("p");
      var lista = todosProdutores().filter(function (p) { return p.consentimento !== false; });
      var ocultos = todosProdutores().length - lista.length;
      var p = alvo && lista.find(function (x) { return x.id === alvo; });
      if (alvo && !p && alvo !== "participar") alvo = "";
      if (p) {
        intro.hidden = true; avisos.hidden = true;
        document.title = p.nome + " · Produtores · PANCverso";
        var ls = lotesDoProdutor(p.id), esps = especiesDoProdutor(p.id);
        root.innerHTML = '<nav class="breadcrumb" aria-label="Você está em"><a href="produtores.html">Produtores</a> / ' + esc(p.nome) + '</nav>' +
          '<div class="prod-hero">' + (p.foto ? '<img src="' + esc(p.foto) + '" alt="Foto da propriedade: ' + esc(p.propriedade || p.nome) + '" onerror="this.remove()">' : "") +
          '<div class="over"><span class="family" style="color:#d8f0cf">' + esc(p.tipo) + ' · ' + esc(p.municipio) + '/' + esc(p.uf) + '</span><h1>' + esc(p.nome) + '</h1>' +
          '<div class="chips">' + (p.sistema && p.sistema !== "—" ? '<span class="chip">' + esc(p.sistema) + '</span>' : "") + '<span class="chip">' + ls.length + (ls.length === 1 ? " lote" : " lotes") + '</span>' +
          (p.simulado ? '<span class="chip chip-sim">Produtor simulado</span>' : p.teste ? '<span class="chip chip-sim">Registro de teste</span>' : "") + '</div></div></div>' + creditoProdutor(p) +
          (p.simulado ? '<div class="notice" role="note" style="margin-top:18px">' + ICON.info + '<div><p><strong>Exemplo simulado.</strong> Este produtor e a foto são fictícios e servem só para demonstrar como a página vai funcionar. Os produtores reais aparecerão após o teste piloto.</p></div></div>' : "") +
          '<div class="two-col" style="margin-top:28px"><section class="panel stack"><h2>Sobre a propriedade</h2>' + (p.historia ? '<p>' + esc(p.historia) + '</p>' : "") +
          '<dl class="kv"><dt>Propriedade</dt><dd>' + esc(p.propriedade) + '</dd><dt>Município</dt><dd>' + esc(p.municipio) + '/' + esc(p.uf) + '</dd><dt>Tipo</dt><dd>' + esc(p.tipo) + '</dd><dt>Sistema de cultivo</dt><dd>' + esc(p.sistema || "—") + '</dd></dl>' +
          '<p class="source">Telefone, endereço e localização exata não são publicados (LGPD).</p></section>' +
          '<section class="stack"><h2 style="font-size:1.4rem">Espécies cultivadas</h2>' + (esps.length ? '<div class="grid-cards" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr))">' + esps.map(function (id) { var e = especie(id); return e ? cardEspecie(e) : ""; }).join("") + '</div>' : '<p class="source">Ainda sem lotes publicados.</p>') + '</section></div>' +
          '<section style="margin-top:36px" class="stack"><h2 style="font-size:1.4rem">Lotes deste produtor</h2><div class="lot-list">' + (ls.length ? ls.map(linhaLote).join("") : '<div class="empty">Ainda sem lotes publicados.</div>') + '</div></section>' +
          '<section style="margin-top:48px" class="stack"><h2 style="font-size:1.4rem">Outros produtores</h2><div class="prod-grid">' + lista.filter(function (x) { return x.id !== p.id; }).map(cardProdutor).join("") + '</div></section>';
        window.scrollTo(0, 0);
        return;
      }
      intro.hidden = false; avisos.hidden = false;
      document.title = "Produtores · PANCverso";
      $("#count").textContent = lista.length + (lista.length === 1 ? " produtor com nome divulgado" : " produtores com nome divulgado") + (ocultos ? " · " + ocultos + " participante(s) sem nome divulgado" : "");
      root.innerHTML = lista.length ? '<div class="prod-grid">' + lista.map(cardProdutor).join("") + '</div>' : '<div class="empty">Nenhum produtor com nome divulgado ainda.</div>';
      if (alvo === "participar") { var el = document.getElementById("participar"); if (el) el.scrollIntoView(); }
    }
    window.addEventListener("hashchange", render);
    render();
  };

  PAGES.panfleto = function () {
    var home = location.href.split("#")[0].split("?")[0].replace(/[^\/]*$/, "") + "index.html";
    $("#pf-qr").innerHTML = qrSvg(home, "QR Code para o site PANCverso");
    $("#pf-url").textContent = home;
    $("#pf-imprimir").addEventListener("click", function () { window.print(); });
  };

  PAGES.avaliar = function () {
    var cod = normalizarCodigo(hashParam("c"));
    var l = cod && lote(cod);
    $("#av-lote").innerHTML = l ? 'Lote <span class="code-tag">' + esc(l.codigo) + '</span> · ' + esc(especie(l.especie).nome) : "Lote não informado";
    var back = $("#av-voltar"); if (l) back.href = "lote.html#" + l.codigo;
    $("#av-status").hidden = !!D.config.pesquisaAtiva;
  };

  /* ---------- Jogo "Adivinhe a PANC" (dentro do Material didático) ---------- */
  function jogo(root) {
    var RECORDE = "pancverso:jogo:recorde";
    var MODOS = {
      classico: { nome: "Clássico", rodadas: 10, tempo: 0, filtro: null, desc: "10 rodadas sem pressa. Quanto menos pistas, mais pontos." },
      relogio: { nome: "Contra o relógio", rodadas: 10, tempo: 20, filtro: null, desc: "20 segundos por rodada. Responder rápido vale bônus." },
      flores: { nome: "Só flores", rodadas: 8, tempo: 0, filtro: function (e) { return categoria(e) === "Flor alimentícia" || e.id === "capuchinha"; }, desc: "8 flores alimentícias para treinar o olhar." }
    };
    var reduz = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var st = {};
    function embaralhar(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function lerRecorde() { try { return JSON.parse(localStorage.getItem(RECORDE)) || {}; } catch (e) { return {}; } }
    function gravarRecorde(m, v) { try { var r = lerRecorde(); if (!r[m] || v > r[m]) { r[m] = v; localStorage.setItem(RECORDE, JSON.stringify(r)); return true; } } catch (e) {} return false; }
    function pistasDe(e) {
      if (e.pistas) return e.pistas;
      return [["Família", "Sou da família " + e.familia + "."], ["Origem", "Minha origem: " + e.origem + "."],
        ["Partes", "Partes comestíveis: " + e.partes.join(", ").toLowerCase() + "."], ["Na cozinha", "Vou bem em: " + e.usos.join(", ").toLowerCase() + "."], ["Dica", e.resumo]];
    }
    function inicio() {
      clearInterval(st.timer);
      var rec = lerRecorde();
      var fotos = embaralhar(D.especies.filter(function (e) { return e.imagem; })).slice(0, 3);
      root.innerHTML = '<div class="game-start">' +
        '<div class="game-hero" style="width:100%"><div class="floaty" aria-hidden="true">' + fotos.map(function (e, i) {
          var pos = [["20px", "70px", "110px"], ["120px", "20px", "80px"], ["110px", "120px", "70px"]][i];
          return '<span style="left:' + pos[0] + ';top:' + pos[1] + ';width:' + pos[2] + ';height:' + pos[2] + ';background-image:url(\'' + esc(e.imagem) + '\');animation-delay:-' + (i * 2) + 's"></span>';
        }).join("") + '</div>' +
        '<span class="eyebrow" style="color:#9fd48f">Jogo educativo</span><h2>Adivinhe a PANC</h2>' +
        '<p>Uma foto desfocada, cinco pistas e quatro opções. A cada pista a foto fica mais nítida, mas vale menos pontos. Acertos seguidos rendem bônus.</p></div>' +
        '<h3 style="font-size:1.1rem">Escolha o modo</h3><div class="modes">' + Object.keys(MODOS).map(function (k) {
          var m = MODOS[k];
          return '<button class="mode" type="button" data-modo="' + k + '"><span class="ico">' + (k === "relogio" ? ICON.clock : k === "flores" ? ICON.flower : ICON.leaf) + '</span><strong>' + esc(m.nome) + '</strong><span>' + esc(m.desc) + '</span>' +
            (rec[k] ? '<span class="chip chip-gold" style="justify-self:start">Recorde: ' + rec[k] + ' pts</span>' : "") + '</button>';
        }).join("") + '</div>' +
        '<p class="source">Funciona no celular e em projetor. Bom para oficinas, feiras e sala de aula (a partir de 10 anos).</p></div>';
      $$(".mode", root).forEach(function (b) { b.addEventListener("click", function () { comecar(b.getAttribute("data-modo")); }); });
    }
    function comecar(modo) {
      var m = MODOS[modo], pool = D.especies.filter(function (e) { return e.imagem && (!m.filtro || m.filtro(e)); });
      st = { modo: modo, m: m, pool: pool, ordem: embaralhar(pool).slice(0, Math.min(m.rodadas, pool.length)), rodada: 0, total: 0, acertos: 0, seq: 0, melhorSeq: 0 };
      novaRodada();
    }
    function novaRodada() {
      var e = st.ordem[st.rodada];
      var mesmo = st.pool.filter(function (x) { return x.id !== e.id && categoria(x) === categoria(e); });
      var resto = st.pool.filter(function (x) { return x.id !== e.id && categoria(x) !== categoria(e); });
      if (mesmo.length < 3) mesmo = mesmo.concat(D.especies.filter(function (x) { return x.id !== e.id && mesmo.indexOf(x) < 0 && categoria(x) === categoria(e); }));
      st.opcoes = embaralhar([e].concat(embaralhar(mesmo).concat(embaralhar(resto)).slice(0, 3)));
      st.pistas = 1; st.resposta = null; st.restante = st.m.tempo;
      desenhar();
      if (st.m.tempo) {
        clearInterval(st.timer);
        var t0 = Date.now();
        st.timer = setInterval(function () {
          st.restante = Math.max(0, st.m.tempo - (Date.now() - t0) / 1000);
          var bar = $(".timer", root);
          if (bar) { $("span", bar).style.transform = "scaleX(" + (st.restante / st.m.tempo) + ")"; bar.classList.toggle("low", st.restante < 6); }
          var tt = $("#t-rest"); if (tt) tt.textContent = Math.ceil(st.restante) + " s";
          if (st.restante <= 0) { clearInterval(st.timer); responder("__tempo__"); }
        }, 100);
      }
    }
    function pontosAgora() { return Math.max(1, 6 - st.pistas) * 10; }
    function desenhar() {
      var e = st.ordem[st.rodada], ps = pistasDe(e), res = st.resposta;
      var blur = res ? 0 : Math.max(3, 26 - (st.pistas - 1) * 6);
      root.innerHTML =
        '<div class="hud"><div><dt>Rodada</dt><dd>' + (st.rodada + 1) + '<span style="font-size:.9rem;color:var(--muted)">/' + st.ordem.length + '</span></dd></div>' +
        '<div><dt>Pontos</dt><dd id="hud-pts">' + st.total + '</dd></div>' +
        '<div class="streak"><dt>Sequência</dt><dd id="hud-seq">' + ICON.flame + ' ' + st.seq + '</dd></div></div>' +
        (st.m.tempo ? '<div style="display:grid;gap:6px"><div class="timer" aria-hidden="true"><span style="transform:scaleX(' + (st.restante / st.m.tempo) + ')"></span></div><span class="source" aria-live="off">Tempo: <b id="t-rest">' + Math.ceil(st.restante) + ' s</b></span></div>' : '<div class="progress" aria-hidden="true"><span style="width:' + (st.rodada / st.ordem.length * 100) + '%"></span></div>') +
        '<div class="arena"><div class="stack" style="gap:8px"><div class="mystery' + (res ? " revealed" : "") + '" style="--blur:' + blur + 'px"><img src="' + esc(e.imagem) + '" alt="' + (res ? esc("Foto de " + e.nome) : "Foto misteriosa, desfocada") + '"><span class="q" aria-hidden="true">?</span>' +
        (res && e.credito ? '<span class="cap">Foto: ' + esc(e.credito.autor) + ' · ' + esc(e.credito.licenca) + '</span>' : "") + '</div>' +
        (!res ? '<p class="source" style="text-align:center">A foto fica mais nítida a cada pista.</p>' : "") + '</div>' +
        '<div class="stack"><div class="stack" style="gap:4px"><h2 style="font-size:1.5rem">Qual planta sou eu?</h2><p class="source">Acertar agora vale <b>' + pontosAgora() + ' pontos</b>' + (st.m.tempo ? " + bônus de tempo" : "") + (st.seq >= 1 ? " + bônus de sequência" : "") + '.</p></div>' +
        '<ol class="clues" aria-live="polite">' + ps.slice(0, res ? ps.length : st.pistas).map(function (p) { return '<li><b>' + esc(p[0]) + '</b><span>' + esc(p[1]) + '</span></li>'; }).join("") + '</ol>' +
        '<div class="options" role="group" aria-label="Escolha uma resposta">' + st.opcoes.map(function (o) {
          var cls = res ? (o.id === e.id ? "right" : (o.id === res ? "wrong" : "")) : "";
          return '<button type="button" data-id="' + o.id + '" class="' + cls + '"' + (res ? " disabled" : "") + '>' + esc(o.nome) + '</button>';
        }).join("") + '</div>' +
        '<div id="feedback" aria-live="assertive"></div>' +
        (!res && st.pistas < ps.length ? '<div class="btn-row"><button class="btn btn-ghost" type="button" id="mais">Mostrar mais uma pista (−10)</button></div>' : "") +
        '</div></div>';
      if (res) {
        var ok = res === e.id;
        $("#feedback").innerHTML = '<div class="notice ' + (ok ? "notice-leaf" : "notice-wine") + '">' + (ok ? ICON.check : ICON.info) + '<div><p><strong>' +
          (ok ? "Acertou! +" + st.ganho + " pontos." : res === "__tempo__" ? "O tempo acabou! Era " + esc(e.nome) + "." : "Quase! Era " + esc(e.nome) + ".") + '</strong></p>' +
          '<p>' + esc(e.resumo) + ' <a href="planta.html#' + e.id + '">Ver a ficha</a>.</p></div></div>' +
          '<div class="btn-row" style="margin-top:14px"><button class="btn btn-primary" type="button" id="prox">' + (st.rodada + 1 < st.ordem.length ? "Próxima rodada" : "Ver resultado") + '</button></div>';
        $("#prox").addEventListener("click", function () { st.rodada++; if (st.rodada < st.ordem.length) novaRodada(); else fim(); });
        $("#prox").focus({ preventScroll: true });
        if (ok) { confete($(".mystery", root)); var hp = $("#hud-pts"), hs = $("#hud-seq"); hp.classList.add("pop"); hs.classList.add("pop"); }
      } else {
        $$(".options button", root).forEach(function (b) { b.addEventListener("click", function () { responder(b.getAttribute("data-id")); }); });
        var mb = $("#mais"); if (mb) mb.addEventListener("click", function () { st.pistas++; desenhar(); var bt = $("#mais"); (bt || $(".options button", root)).focus({ preventScroll: true }); });
      }
    }
    function responder(id) {
      if (st.resposta) return;
      clearInterval(st.timer);
      var e = st.ordem[st.rodada];
      st.resposta = id; st.ganho = 0;
      if (id === e.id) {
        st.seq++; st.acertos++; st.melhorSeq = Math.max(st.melhorSeq, st.seq);
        st.ganho = pontosAgora() + (st.m.tempo ? Math.ceil(st.restante) : 0) + (st.seq >= 2 ? 5 * Math.min(st.seq - 1, 4) : 0);
        st.total += st.ganho;
      } else { st.seq = 0; }
      desenhar();
    }
    function confete(alvo) {
      if (reduz || !alvo) return;
      var b = document.createElement("div"); b.className = "burst";
      var cores = ["#9fd48f", "#e3a92b", "#ec8a9c", "#2f6b2c", "#fff"];
      for (var i = 0; i < 26; i++) {
        var a = Math.random() * Math.PI * 2, d = 80 + Math.random() * 120, it = document.createElement("i");
        it.style.cssText = "--x:50%;--y:50%;--c:" + cores[i % cores.length] + ";--dx:" + Math.round(Math.cos(a) * d) + "px;--dy:" + Math.round(Math.sin(a) * d) + "px;--r:" + Math.round(Math.random() * 540) + "deg;animation-delay:" + (Math.random() * .12).toFixed(2) + "s";
        b.appendChild(it);
      }
      alvo.appendChild(b); setTimeout(function () { b.remove(); }, 1400);
    }
    function fim() {
      var max = st.ordem.length * (50 + (st.m.tempo ? 20 : 0)), r = st.total / max;
      var tier = r >= .7 ? ["Mestre das PANC", "#c99410", "#f5d76e", "★"] : r >= .4 ? ["Colhedor experiente", "#7f8c99", "#dfe6ec", "✿"] : ["Broto curioso", "#9a5b2e", "#e8b48a", "❀"];
      var novo = gravarRecorde(st.modo, st.total);
      root.innerHTML = '<div class="panel" style="text-align:center;justify-items:center;gap:12px">' +
        '<div class="medal" style="--m1:' + tier[1] + ';--m2:' + tier[2] + '" aria-hidden="true">' + tier[3] + '</div>' +
        '<span class="eyebrow">' + esc(st.m.nome) + ' · resultado</span><p class="score-big">' + st.total + '<span style="font-size:1.2rem;color:var(--muted)"> pontos</span></p>' +
        '<p style="font-size:1.3rem;font-weight:800;font-family:var(--font-display)">' + tier[0] + '</p>' +
        (novo ? '<span class="chip chip-gold">Novo recorde neste aparelho!</span>' : "") +
        '<p class="source">' + st.acertos + ' de ' + st.ordem.length + ' acertos · melhor sequência: ' + st.melhorSeq + '</p>' +
        '<div class="btn-row" style="justify-content:center"><button class="btn btn-primary" type="button" id="denovo">Jogar de novo</button><button class="btn btn-ghost" type="button" id="outro">Trocar de modo</button><a class="btn btn-ghost" href="catalogo.html">Estudar no catálogo</a></div></div>';
      if (tier[0] === "Mestre das PANC") confete($(".panel", root));
      $("#denovo").addEventListener("click", function () { comecar(st.modo); });
      $("#outro").addEventListener("click", inicio);
      $("#denovo").focus({ preventScroll: true });
    }
    inicio();
  }

  PAGES.material = function () {
    var root = $("#jogo"); if (root) jogo(root);
    if (location.hash === "#jogo" && root) setTimeout(function () { document.getElementById("jogo-sec").scrollIntoView(); }, 50);
  };

  PAGES.etiquetas = function () {
    var sel = $("#et-lote"), fmt = $("#et-formato"), area = $("#et-area");
    sel.innerHTML = LOTES.map(function (l) { return '<option value="' + l.codigo + '">' + l.codigo + ' · ' + esc(especie(l.especie).nome) + '</option>'; }).join("");
    var pre = normalizarCodigo(hashParam("c")); if (pre && lote(pre)) sel.value = pre;
    function render() {
      var l = lote(sel.value), html = etiquetaHtml(l);
      if (fmt.value === "a4") { area.className = "print-area sheet-a4"; area.innerHTML = new Array(9).join(html); }
      else { area.className = "print-area print-single"; area.innerHTML = html; }
      $("#et-url").textContent = urlLote(l.codigo);
    }
    sel.addEventListener("change", render); fmt.addEventListener("change", render);
    $("#et-imprimir").addEventListener("click", function () { window.print(); });
    render();
  };

  document.addEventListener("DOMContentLoaded", function () {
    comum();
    var p = document.body.getAttribute("data-page");
    if (PAGES[p]) PAGES[p]();
  });

  window.PV = { normalizarCodigo: normalizarCodigo, urlLote: urlLote, esc: esc, fmtData: fmtData, fmtKg: fmtKg, especie: especie,
    lerLocal: lerLocal, gravarLocal: gravarLocal, todosLotes: todosLotes, todosProdutores: todosProdutores, produtor: produtor,
    etiquetaHtml: etiquetaHtml, toast: toast, copiar: copiar, ICON: ICON, PAGES: PAGES, media: media };
})();

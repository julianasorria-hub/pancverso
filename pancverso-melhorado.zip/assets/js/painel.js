/* =====================================================================
   PANCverso — área da pesquisadora (login e painel)
   ---------------------------------------------------------------------
   ATENÇÃO: num site estático, o login é apenas uma barreira simples no
   navegador. Ele evita acesso casual, mas não protege dados contra quem
   sabe inspecionar o código. Os dados restritos (contato, endereço, GPS,
   fornecedor, qualidade, responsável) ficam SOMENTE no navegador da
   pesquisadora (localStorage) e nunca vão para o dados.js público.
   ===================================================================== */
(function () {
  "use strict";
  var USUARIO = "123", SENHA = "teste";
  var SESSAO = "pancverso:sessao", RASCUNHO = "pancverso:rascunho:v1";
  var PV = window.PV, D = window.PANC, esc = PV.esc;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function logado() { try { return sessionStorage.getItem(SESSAO) === "ok"; } catch (e) { return window.__pvSessao === "ok"; } }
  function entrar() { try { sessionStorage.setItem(SESSAO, "ok"); } catch (e) { window.__pvSessao = "ok"; } }
  function sair() { try { sessionStorage.removeItem(SESSAO); } catch (e) { window.__pvSessao = ""; } }

  var ORIGENS = ["Cultivo próprio", "Coleta em área silvestre/natural", "Compra de fornecedor certificado"];
  var METODOS = ["Orgânico / agroecológico", "Convencional", "Hidroponia", "Não se aplica"];
  var PARTES = ["Folhas", "Flores", "Caules/talos", "Raízes/tubérculos", "Frutos/sementes"];
  var CATEGORIAS = ["In natura", "Panificação", "Doce/sobremesa", "Conservas/fermentados", "Bebida/chá/suco", "Prato pronto", "Ingrediente seco", "Outro"];
  var PREPAROS = ["Saladas cruas", "Refogados e omeletes", "Chás e infusões", "Pães, bolos e biscoitos", "Geleias e compotas", "Sopas e caldos", "Recheios", "Aproveitamento integral", "Bebidas fermentadas"];
  var TIPOS = ["Sítio", "Quintal produtivo", "Horta agroecológica", "Horta comunitária", "Outro"];

  function opts(arr, sel) { return arr.map(function (v) { return '<option' + (v === sel ? " selected" : "") + '>' + esc(v) + '</option>'; }).join(""); }
  function radios(name, arr, req) { return arr.map(function (v, i) { return '<label class="opt"><input type="radio" name="' + name + '" value="' + esc(v) + '"' + (req && i === 0 ? " required" : "") + '> ' + esc(v) + '</label>'; }).join(""); }
  function checks(name, arr) { return arr.map(function (v) { return '<label class="opt"><input type="checkbox" name="' + name + '" value="' + esc(v) + '"> ' + esc(v) + '</label>'; }).join(""); }
  function slug(t) { return t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "produtor"; }
  function hoje() { var d = new Date(); return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); }
  function baixar(nome, conteudo, tipo) {
    try {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([conteudo], { type: tipo }));
      a.download = nome; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
      PV.toast("Arquivo " + nome + " gerado");
    } catch (e) { PV.toast("Não foi possível baixar. Use o botão Copiar."); }
  }

  /* ---------------- Login ---------------- */
  PV.PAGES.login = function () {
    if (logado()) { location.replace("painel.html"); return; }
    var f = $("#form-login");
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var u = $("#l-usuario").value.trim(), s = $("#l-senha").value;
      var err = $("#l-erro");
      if (u === USUARIO && s === SENHA) { entrar(); location.href = "painel.html"; return; }
      err.hidden = false; err.textContent = "Usuário ou senha incorretos. Confira e tente de novo.";
      $("#l-senha").value = ""; $("#l-senha").focus();
    });
  };

  /* ---------------- Painel ---------------- */
  PV.PAGES.painel = function () {
    if (!logado()) { location.replace("login.html"); return; }
    $("#painel").hidden = false;
    $("#sair").addEventListener("click", function () { sair(); location.href = "login.html"; });

    // Abas (com link direto por #lotes, #novo, #produtores, #exportar)
    var tabs = $$('[role="tab"]');
    function abrir(id, focar) {
      tabs.forEach(function (t) {
        var on = t.getAttribute("aria-controls") === "pn-" + id;
        t.setAttribute("aria-selected", on); t.tabIndex = on ? 0 : -1;
        $("#" + t.getAttribute("aria-controls")).hidden = !on;
        if (on && focar) t.focus();
      });
    }
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { abrir(t.getAttribute("aria-controls").slice(3)); history.replaceState(null, "", "#" + t.getAttribute("aria-controls").slice(3)); });
      t.addEventListener("keydown", function (ev) {
        var j = ev.key === "ArrowRight" ? (i + 1) % tabs.length : ev.key === "ArrowLeft" ? (i - 1 + tabs.length) % tabs.length : null;
        if (j !== null) { ev.preventDefault(); abrir(tabs[j].getAttribute("aria-controls").slice(3), true); }
      });
    });
    $$("[data-aba]").forEach(function (l) { l.addEventListener("click", function (ev) { ev.preventDefault(); abrir(l.getAttribute("data-aba"), true); }); });
    var inicial = (location.hash || "#lotes").slice(1);
    abrir(["lotes", "novo", "produtores", "exportar"].indexOf(inicial) > -1 ? inicial : "lotes");

    montarFormLote();
    montarFormProdutor();
    montarExportar();
    atualizar();
  };

  function atualizar() {
    var loc = PV.lerLocal();
    var todos = PV.todosLotes(true), ativos = todos.filter(function (l) { return loc.arquivados.indexOf(l.codigo) < 0 && !l.arquivado; });
    var acessos = Object.keys(loc.acessos).reduce(function (s, k) { return s + loc.acessos[k]; }, 0);
    $("#k-lotes").textContent = ativos.length;
    $("#k-produtores").textContent = PV.todosProdutores().length;
    $("#k-arquivados").textContent = todos.length - ativos.length;
    $("#k-acessos").textContent = acessos;
    listaLotes(); listaProdutores(); selectProdutores();
  }

  /* ----- Lista de lotes ----- */
  var filtrosProntos = false;
  function listaLotes() {
    var fEsp = $("#pl-especie"), fProd = $("#pl-produtor"), fArq = $("#pl-arquivados"), busca = $("#pl-busca");
    if (!filtrosProntos) {
      fEsp.innerHTML = '<option value="">Todas as espécies</option>' + D.especies.map(function (e) { return '<option value="' + e.id + '">' + esc(e.nome) + '</option>'; }).join("");
      [fEsp, fProd, fArq].forEach(function (x) { x.addEventListener("change", listaLotes); });
      busca.addEventListener("input", listaLotes);
      filtrosProntos = true;
    }
    var atualProd = fProd.value;
    fProd.innerHTML = '<option value="">Todos os produtores</option>' + PV.todosProdutores().map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.nome) + '</option>'; }).join("");
    fProd.value = atualProd;
    var loc = PV.lerLocal(), q = busca.value.trim().toLowerCase();
    var locais = loc.lotes.map(function (l) { return l.codigo; });
    var lista = PV.todosLotes(true).filter(function (l) {
      var arq = loc.arquivados.indexOf(l.codigo) > -1 || l.arquivado;
      var e = PV.especie(l.especie) || {}, p = PV.produtor(l.produtor) || {};
      return (fArq.checked || !arq) && (!fEsp.value || l.especie === fEsp.value) && (!fProd.value || l.produtor === fProd.value) &&
        (!q || [l.codigo, e.nome, p.nome].join(" ").toLowerCase().indexOf(q) > -1);
    }).sort(function (a, b) { return b.codigo.localeCompare(a.codigo); });
    $("#pl-count").textContent = lista.length + (lista.length === 1 ? " lote" : " lotes");
    $("#pl-corpo").innerHTML = lista.length ? lista.map(function (l) {
      var e = PV.especie(l.especie) || {}, p = PV.produtor(l.produtor) || {}, pv = loc.privado[l.codigo] || {};
      var arq = loc.arquivados.indexOf(l.codigo) > -1 || l.arquivado;
      return '<tr' + (arq ? ' class="arq"' : "") + '><td><span class="code-tag">' + esc(l.codigo) + '</span>' + (l.teste ? '<br><span class="source">teste</span>' : "") + (arq ? '<br><span class="chip">Arquivado</span>' : "") + '</td>' +
        '<td>' + esc(e.nome) + '</td><td>' + esc(p.nome || "—") + '</td><td class="num">' + PV.fmtData(l.colheita) + '</td><td>' + esc(l.origem) + '</td><td>' + esc(l.categoria) + '</td>' +
        '<td class="num">' + PV.fmtKg(l.pesoKg) + '</td><td class="num">' + (pv.qualidade ? esc(pv.qualidade) + "/5" : "—") + '</td><td>' + esc(pv.responsavel || "—") + '</td><td class="num">' + (loc.acessos[l.codigo] || 0) + '</td>' +
        '<td><div class="btn-row" style="gap:6px;flex-wrap:nowrap"><a class="btn btn-ghost btn-sm" href="lote.html#' + esc(l.codigo) + '">Ficha</a><a class="btn btn-ghost btn-sm" href="etiquetas.html#' + esc(l.codigo) + '">Etiqueta</a>' +
        '<button class="btn btn-ghost btn-sm" type="button" data-arq="' + esc(l.codigo) + '">' + (arq ? "Restaurar" : "Arquivar") + '</button>' +
        (locais.indexOf(l.codigo) > -1 ? '<button class="btn btn-ghost btn-sm" type="button" data-del="' + esc(l.codigo) + '">Excluir</button>' : "") + '</div></td></tr>';
    }).join("") : '<tr><td colspan="11"><div class="empty">Nenhum lote com esses filtros.</div></td></tr>';
    $$("[data-arq]").forEach(function (b) {
      b.addEventListener("click", function () {
        var c = b.getAttribute("data-arq"), v = PV.lerLocal(), i = v.arquivados.indexOf(c);
        if (i > -1) v.arquivados.splice(i, 1); else v.arquivados.push(c);
        PV.gravarLocal(v); PV.toast(i > -1 ? "Lote " + c + " restaurado" : "Lote " + c + " arquivado: não aparece mais no site"); atualizar();
      });
    });
    $$("[data-del]").forEach(function (b) {
      b.addEventListener("click", function () {
        var c = b.getAttribute("data-del");
        if (b.getAttribute("data-confirmar") !== "1") { b.setAttribute("data-confirmar", "1"); b.textContent = "Confirmar exclusão"; b.classList.add("btn-primary"); return; }
        var v = PV.lerLocal();
        v.lotes = v.lotes.filter(function (l) { return l.codigo !== c; }); delete v.privado[c];
        PV.gravarLocal(v); PV.toast("Lote " + c + " excluído"); atualizar();
      });
    });
  }

  /* ----- Formulário de lote (Apêndice A) ----- */
  function selectProdutores() {
    var s = $("#nl-produtor"), atual = s.value;
    s.innerHTML = '<option value="">Selecione o produtor</option>' + PV.todosProdutores().map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.nome) + ' (' + esc(p.municipio) + ')</option>'; }).join("");
    if (atual) s.value = atual;
  }
  function montarFormLote() {
    $("#nl-especie").innerHTML = '<option value="">Selecione a espécie</option>' + D.especies.map(function (e) { return '<option value="' + e.id + '">' + esc(e.nome) + ' (' + esc(e.cientifico) + ')</option>'; }).join("");
    $("#nl-origem").innerHTML = radios("origem", ORIGENS, true);
    $("#nl-metodo").innerHTML = radios("metodo", METODOS, true);
    $("#nl-partes").innerHTML = checks("partes", PARTES);
    $("#nl-categoria").innerHTML = opts(CATEGORIAS, "In natura");
    $("#nl-preparos").innerHTML = checks("preparos", PREPAROS);
    $("#nl-colheita").value = hoje();
    var f = $("#form-lote");
    var fotoData = "";

    $("#nl-especie").addEventListener("change", function () {
      var e = PV.especie(this.value);
      $("#nl-cientifico").textContent = e ? e.cientifico + " · " + e.familia : "";
    });
    f.addEventListener("change", function (ev) {
      if (ev.target.name === "origem") $("#nl-fornecedor-box").hidden = ev.target.value.indexOf("Compra") !== 0;
    });
    $("#nl-gps").addEventListener("click", function () {
      var st = $("#nl-gps-status");
      if (!navigator.geolocation) { st.textContent = "Este aparelho não oferece localização. Digite as coordenadas, se tiver."; return; }
      st.textContent = "Obtendo localização…";
      navigator.geolocation.getCurrentPosition(function (pos) {
        $("#nl-lat").value = pos.coords.latitude.toFixed(6); $("#nl-lng").value = pos.coords.longitude.toFixed(6);
        st.textContent = "Localização registrada (precisão de cerca de " + Math.round(pos.coords.accuracy) + " m)."; salvarRascunho();
      }, function () { st.textContent = "Não foi possível obter a localização. Verifique a permissão do navegador ou digite as coordenadas."; }, { enableHighAccuracy: true, timeout: 15000 });
    });
    $("#nl-foto").addEventListener("change", function () {
      var file = this.files && this.files[0], prev = $("#nl-foto-prev");
      if (!file) { fotoData = ""; prev.innerHTML = ""; return; }
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var max = 900, k = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        fotoData = c.toDataURL("image/jpeg", 0.72);
        prev.innerHTML = '<img src="' + fotoData + '" alt="Prévia da foto do lote" style="max-height:180px;border-radius:8px">';
        URL.revokeObjectURL(url);
      };
      img.onerror = function () { prev.textContent = "Não foi possível ler esta imagem. Use uma foto JPG ou PNG."; };
      img.src = url;
    });

    // Rascunho automático (para campo com internet instável)
    var timer;
    function salvarRascunho() {
      var dados = {};
      $$("input, select, textarea", f).forEach(function (el) {
        if (!el.name || el.type === "file") return;
        if (el.type === "radio") { if (el.checked) dados[el.name] = el.value; }
        else if (el.type === "checkbox") { dados[el.name] = dados[el.name] || []; if (el.checked) dados[el.name].push(el.value); }
        else dados[el.name] = el.value;
      });
      try { localStorage.setItem(RASCUNHO, JSON.stringify(dados)); } catch (e) { return; }
      var d = new Date(); $("#nl-rascunho").textContent = "Rascunho salvo neste aparelho às " + ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ".";
    }
    f.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(salvarRascunho, 400); });
    f.addEventListener("change", function () { clearTimeout(timer); timer = setTimeout(salvarRascunho, 200); });
    try {
      var r = JSON.parse(localStorage.getItem(RASCUNHO));
      if (r) {
        $$("input, select, textarea", f).forEach(function (el) {
          if (!el.name || !(el.name in r) || el.type === "file") return;
          if (el.type === "radio") el.checked = r[el.name] === el.value;
          else if (el.type === "checkbox") el.checked = (r[el.name] || []).indexOf(el.value) > -1;
          else el.value = r[el.name];
        });
        $("#nl-rascunho").textContent = "Rascunho anterior recuperado.";
        var o = f.querySelector('input[name="origem"]:checked'); if (o) $("#nl-fornecedor-box").hidden = o.value.indexOf("Compra") !== 0;
        $("#nl-especie").dispatchEvent(new Event("change"));
      }
    } catch (e) { /* sem rascunho */ }

    $("#nl-limpar").addEventListener("click", function () {
      f.reset(); fotoData = ""; $("#nl-foto-prev").innerHTML = ""; $("#nl-colheita").value = hoje();
      try { localStorage.removeItem(RASCUNHO); } catch (e) { /* ok */ }
      $("#nl-rascunho").textContent = "Formulário limpo.";
    });

    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var erros = [];
      var g = function (n) { var el = f.elements[n]; return el ? (el.value || "").trim() : ""; };
      var marcados = function (n) { return $$('input[name="' + n + '"]:checked', f).map(function (x) { return x.value; }); };
      if (!g("produtor")) erros.push(["nl-produtor", "Selecione o produtor."]);
      if (!g("especie")) erros.push(["nl-especie", "Selecione a espécie."]);
      if (!marcados("origem").length) erros.push(["nl-origem", "Informe a origem da PANC."]);
      if (!g("colheita")) erros.push(["nl-colheita", "Informe a data da colheita."]);
      if (g("inicio") && g("colheita") && g("inicio") > g("colheita")) erros.push(["nl-inicio", "A data de início deve ser anterior à colheita."]);
      if (!marcados("metodo").length) erros.push(["nl-metodo", "Informe o método de cultivo."]);
      if (!marcados("partes").length) erros.push(["nl-partes", "Marque ao menos uma parte utilizada."]);
      var box = $("#nl-erros");
      if (erros.length) {
        box.hidden = false;
        box.innerHTML = "<p><strong>Faltam informações:</strong></p><ul>" + erros.map(function (e) { return '<li><a href="#' + e[0] + '">' + esc(e[1]) + "</a></li>"; }).join("") + "</ul>";
        box.focus(); return;
      }
      box.hidden = true;
      var loc = PV.lerLocal();
      var ano = new Date().getFullYear(), maior = 0;
      PV.todosLotes(true).forEach(function (l) { var m = l.codigo.match(/^PANC-(\d{4})-(\d{4})$/); if (m && +m[1] === ano) maior = Math.max(maior, +m[2]); });
      var codigo = "PANC-" + ano + "-" + ("000" + (maior + 1)).slice(-4);
      var peso = parseFloat(g("peso").replace(",", "."));
      loc.lotes.push({
        codigo: codigo, especie: g("especie"), produtor: g("produtor"), origem: marcados("origem")[0],
        inicio: g("inicio"), colheita: g("colheita"), metodo: marcados("metodo")[0],
        manejo: { adubacao: g("adubacao") || "—", irrigacao: g("irrigacao") || "—", pragas: g("pragas") || "—" },
        pesoKg: isNaN(peso) ? null : peso, partes: marcados("partes"), processamento: g("processamento") || "—",
        categoria: g("categoria"), preparos: marcados("preparos"), ingredientes: g("ingredientes"), foto: fotoData || "",
        cadastradoEm: new Date().toISOString()
      });
      loc.privado[codigo] = {
        fornecedor: g("fornecedor"), endereco: g("endereco"), lat: g("lat"), lng: g("lng"),
        qualidade: g("qualidade"), responsavel: g("responsavel"), observacoes: g("observacoes")
      };
      if (!PV.gravarLocal(loc)) { box.hidden = false; box.innerHTML = "<p><strong>Não foi possível salvar.</strong> O armazenamento do navegador está cheio ou bloqueado. Tente sem foto ou exporte um backup e limpe dados antigos.</p>"; return; }
      try { localStorage.removeItem(RASCUNHO); } catch (e) { /* ok */ }
      f.reset(); fotoData = ""; $("#nl-foto-prev").innerHTML = ""; $("#nl-colheita").value = hoje(); $("#nl-cientifico").textContent = "";
      var ok = $("#nl-ok");
      ok.hidden = false;
      ok.innerHTML = PV.ICON.check + '<div><p><strong>Lote ' + esc(codigo) + ' cadastrado.</strong> A ficha pública e a etiqueta já estão prontas neste navegador. Para publicar para todos, use a aba Exportar.</p>' +
        '<div class="btn-row" style="margin-top:8px"><a class="btn btn-primary btn-sm" href="lote.html#' + codigo + '">Abrir ficha</a><a class="btn btn-ghost btn-sm" href="etiquetas.html#' + codigo + '">Imprimir etiqueta</a></div></div>';
      ok.scrollIntoView({ block: "center" });
      atualizar();
    });
  }

  /* ----- Produtores ----- */
  function listaProdutores() {
    var loc = PV.lerLocal(), todos = PV.todosLotes(true);
    var locais = loc.produtores.map(function (p) { return p.id; });
    $("#pp-corpo").innerHTML = PV.todosProdutores().map(function (p) {
      var n = todos.filter(function (l) { return l.produtor === p.id; }).length, pv = loc.privadoProdutor[p.id] || {};
      return '<tr><td><strong>' + esc(p.nome) + '</strong><br><span class="source">' + esc(p.propriedade) + '</span></td><td>' + esc(p.municipio) + '/' + esc(p.uf) + '</td><td>' + esc(p.tipo) + '</td>' +
        '<td>' + (p.consentimento === false ? '<span class="no">Não</span>' : '<span class="yes">Sim</span>') + '</td><td class="num">' + n + '</td><td>' + esc(pv.contato || "—") + '</td>' +
        '<td><div class="btn-row" style="gap:6px;flex-wrap:nowrap"><a class="btn btn-ghost btn-sm" href="produtores.html#' + esc(p.id) + '">Ver público</a>' +
        (locais.indexOf(p.id) > -1 && !n ? '<button class="btn btn-ghost btn-sm" type="button" data-delp="' + esc(p.id) + '">Excluir</button>' : "") + '</div></td></tr>';
    }).join("");
    $$("[data-delp]").forEach(function (b) {
      b.addEventListener("click", function () {
        if (b.getAttribute("data-confirmar") !== "1") { b.setAttribute("data-confirmar", "1"); b.textContent = "Confirmar"; b.classList.add("btn-primary"); return; }
        var id = b.getAttribute("data-delp"), v = PV.lerLocal();
        v.produtores = v.produtores.filter(function (p) { return p.id !== id; }); delete v.privadoProdutor[id];
        PV.gravarLocal(v); PV.toast("Produtor excluído"); atualizar();
      });
    });
  }
  function montarFormProdutor() {
    $("#np-tipo").innerHTML = opts(TIPOS, "Sítio");
    var f = $("#form-produtor"), fotoProd = "";
    $("#np-foto").addEventListener("change", function () {
      var file = this.files && this.files[0], prev = $("#np-foto-prev");
      if (!file) { fotoProd = ""; prev.innerHTML = ""; return; }
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var max = 1280, k = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        fotoProd = c.toDataURL("image/jpeg", 0.72);
        prev.innerHTML = '<img src="' + fotoProd + '" alt="Prévia da foto da propriedade" style="max-height:180px;border-radius:8px">';
        URL.revokeObjectURL(url);
      };
      img.onerror = function () { prev.textContent = "Não foi possível ler esta imagem. Use uma foto JPG ou PNG."; };
      img.src = url;
    });
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var g = function (n) { return (f.elements[n].value || "").trim(); };
      var err = $("#np-erro");
      if (!g("nome") || !g("municipio")) { err.hidden = false; err.textContent = "Preencha pelo menos o nome e o município."; (g("nome") ? $("#np-municipio") : $("#np-nome")).focus(); return; }
      err.hidden = true;
      var v = PV.lerLocal(), base = slug(g("nome")), id = base, i = 2;
      while (PV.produtor(id)) { id = base + "-" + i++; }
      v.produtores.push({ id: id, nome: g("nome"), propriedade: g("propriedade") || g("nome"), municipio: g("municipio"), uf: (g("uf") || "RJ").toUpperCase(), tipo: g("tipo"), sistema: g("sistema") || "—", historia: g("historia"), consentimento: f.elements.consentimento.checked, foto: fotoProd || "" });
      v.privadoProdutor[id] = { contato: g("contato"), endereco: g("endereco") };
      if (!PV.gravarLocal(v)) { err.hidden = false; err.textContent = "Não foi possível salvar: o armazenamento do navegador está cheio. Tente com uma foto menor ou sem foto."; return; }
      f.reset(); $("#np-uf").value = "RJ"; fotoProd = ""; $("#np-foto-prev").innerHTML = "";
      PV.toast("Produtor cadastrado"); atualizar();
      $("#nl-produtor").value = id;
    });
  }

  /* ----- Exportar e backup ----- */
  function lotesComArquivo() {
    var loc = PV.lerLocal();
    return D.lotes.concat(loc.lotes).map(function (l) {
      var c = Object.assign({}, l); delete c._p;
      if (loc.arquivados.indexOf(l.codigo) > -1) c.arquivado = true;
      return c;
    });
  }
  function gerarDadosJs() {
    var pub = { config: D.config, noticias: D.noticias || [], tenc: D.tenc || [], produtores: PV.todosProdutores(), especies: D.especies, lotes: lotesComArquivo() };
    pub.config = Object.assign({}, D.config, { atualizadoEm: hoje() });
    return "/* PANCverso — dados.js gerado pelo painel em " + new Date().toLocaleString("pt-BR") + ".\n" +
      "   Contém SOMENTE dados públicos. Substitua assets/js/dados.js no servidor por este arquivo. */\n\nwindow.PANC = " + JSON.stringify(pub, null, 2) + ";\n";
  }
  function gerarCsv() {
    var loc = PV.lerLocal();
    var col = ["codigo", "especie", "nome_cientifico", "produtor", "municipio", "origem", "fornecedor", "inicio", "colheita", "metodo", "adubacao", "irrigacao", "controle_pragas", "peso_kg", "partes", "processamento", "categoria", "preparos", "ingredientes", "qualidade", "responsavel", "endereco", "latitude", "longitude", "observacoes", "acessos_neste_navegador", "arquivado", "teste"];
    var q = function (v) { v = v == null ? "" : String(v); return /[";\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var linhas = lotesComArquivo().map(function (l) {
      var e = PV.especie(l.especie) || {}, p = PV.produtor(l.produtor) || {}, pv = loc.privado[l.codigo] || {}, m = l.manejo || {};
      return [l.codigo, e.nome, e.cientifico, p.nome, (p.municipio || "") + "/" + (p.uf || ""), l.origem, pv.fornecedor, l.inicio, l.colheita, l.metodo, m.adubacao, m.irrigacao, m.pragas,
        l.pesoKg == null ? "" : String(l.pesoKg).replace(".", ","), (l.partes || []).join(", "), l.processamento, l.categoria, (l.preparos || []).join(", "), l.ingredientes,
        pv.qualidade, pv.responsavel, pv.endereco, pv.lat, pv.lng, pv.observacoes, loc.acessos[l.codigo] || 0, l.arquivado ? "sim" : "não", l.teste ? "sim" : "não"].map(q).join(";");
    });
    return "﻿" + col.join(";") + "\n" + linhas.join("\n") + "\n";
  }
  function montarExportar() {
    $("#ex-csv").addEventListener("click", function () { baixar("pancverso-lotes-" + hoje() + ".csv", gerarCsv(), "text/csv;charset=utf-8"); });
    $("#ex-dados").addEventListener("click", function () { baixar("dados.js", gerarDadosJs(), "text/javascript;charset=utf-8"); });
    $("#ex-dados-copiar").addEventListener("click", function () { PV.copiar(gerarDadosJs(), "Conteúdo do dados.js copiado"); });
    $("#ex-backup").addEventListener("click", function () { baixar("pancverso-backup-" + hoje() + ".json", JSON.stringify(PV.lerLocal(), null, 2), "application/json"); });
    $("#ex-importar").addEventListener("change", function () {
      var file = this.files && this.files[0], st = $("#ex-status"); if (!file) return;
      var r = new FileReader();
      r.onload = function () {
        try {
          var v = JSON.parse(r.result);
          if (!v || !Array.isArray(v.lotes)) throw new Error("formato");
          PV.gravarLocal(v); st.textContent = "Backup restaurado: " + v.lotes.length + " lote(s) cadastrados no painel."; atualizar();
        } catch (e) { st.textContent = "Este arquivo não é um backup do PANCverso. Use o .json gerado pelo botão Baixar backup."; }
      };
      r.readAsText(file);
    });
    $("#ex-limpar").addEventListener("click", function () {
      var b = this;
      if (b.getAttribute("data-confirmar") !== "1") { b.setAttribute("data-confirmar", "1"); b.textContent = "Confirmar: apagar cadastros deste navegador"; b.classList.add("btn-primary"); return; }
      try { localStorage.removeItem("pancverso:dados:v1"); localStorage.removeItem(RASCUNHO); } catch (e) { /* ok */ }
      b.removeAttribute("data-confirmar"); b.textContent = "Apagar dados deste navegador"; b.classList.remove("btn-primary");
      $("#ex-status").textContent = "Dados locais apagados. Os registros de teste do dados.js continuam."; atualizar();
    });
  }
})();

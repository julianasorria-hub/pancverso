# PANCverso: site estático (versão 26/11/2026)

**PANCverso: da terra à mesa, cada lote com sua história.**

Site do PANCverso feito do zero em HTML, CSS e JavaScript puros, alinhado ao projeto de dissertação de
Juliana Moraes Sorria (Mestrado Profissional em Ciências Ambientais, Universidade de Vassouras).

Não depende de nenhum serviço externo além das fontes do Google Fonts (opcionais: sem internet,
o navegador usa fontes do sistema). Fotos, gerador de QR Code e panfleto estão na pasta.
Basta abrir `index.html` ou publicar a pasta em qualquer hospedagem estática
(GitHub Pages, Netlify, Cloudflare Pages, servidor da Universidade).

## Páginas públicas

Menu: Início · Produtores · Lotes · Catálogo · Material didático · Sobre.

| Arquivo | O que é |
|---|---|
| `index.html` | Início: barra de notícias, consulta por código do lote, o que são PANC, catálogo, como funciona, lotes recentes, ODS, dúvidas e contato |
| `produtores.html` / `produtores.html#sitio-boa-vista` | Produtores com foto da propriedade em miniatura; ao abrir, a mesma foto em destaque, espécies e lotes |
| `lotes.html` / `lote.html#PANC-2026-0003` | Lotes rastreados e ficha pública do lote (destino do QR Code) |
| `catalogo.html` / `planta.html#taioba` | Catálogo com 40 espécies (PANC, flores, TENC e partes não convencionais) e ficha da espécie |
| `material-didatico.html` | Jogo “Adivinhe a PANC” (3 modos), panfleto, etiquetas e guia do QR Code. `jogo.html` redireciona para cá |
| `avaliar.html` | Questionário do consumidor: “Pesquisa ainda não iniciada” até a aprovação do CEP |
| `panfleto.html`, `etiquetas.html` | Panfleto imprimível com QR Code e etiquetas 10 × 6 cm / A4 |
| `sobre.html` | Objetivos, vínculo com o Programa CapacitAgro, método, privacidade (LGPD), referências e logos |

## Área da pesquisadora

`login.html` → `painel.html`. **Usuário: 123 · Senha: teste** (definidos no início de `assets/js/painel.js`).

O painel tem: indicadores, lista de lotes com busca e filtros, arquivar/restaurar, formulário
de novo lote com as 6 etapas do Apêndice A (rascunho automático, GPS, foto), cadastro de
produtores, exportação CSV, backup e geração do `dados.js`.

**Limitações de um site estático (importante):**

- O login só impede o acesso casual. Quem abrir o código-fonte vê usuário e senha. Para
  proteção real é preciso um servidor com autenticação.
- Os cadastros feitos no painel ficam salvos **no navegador da pesquisadora** (localStorage).
  Eles aparecem no site apenas naquele aparelho até serem publicados.
- **Para publicar:** painel → Exportar → *Baixar dados.js* → substituir `assets/js/dados.js`
  no servidor. O arquivo gerado contém só dados públicos; contato, endereço, GPS, fornecedor,
  qualidade, responsável e observações nunca saem do painel.
- Faça **backup** (painel → Exportar) com frequência: limpar os dados do navegador apaga os cadastros.
- A contagem de acessos às fichas vale só para o aparelho em uso.

## Como editar o conteúdo à mão

Tudo fica em **`assets/js/dados.js`**: `config` (contatos, endereço do QR Code, questionário),
`noticias` (barra de notícias da página inicial), `tenc`, `produtores`, `especies` e `lotes`.

- **Barra de notícias:** edite a lista `noticias`. Cada item tem `tipo` ("Como usar", "Novidade" ou
  "Atualização"), `texto` e, se quiser, `link`. A barra para quando o mouse passa por cima e tem botão de pausa.
- **Espécies:** as 4 primeiras têm ficha completa (nutrição, receitas, pistas do jogo). As outras 36
  vêm do guia *Capacitação em PANC* (Programa CapacitAgro, PESAGRO-RIO, 2024), com identificação e
  usos culinários. Para completar uma ficha, acrescente `nutricao`, `preparo`, `cuidados`,
  `identificacao`, `receitas` e `pistas` seguindo o modelo da ora-pro-nóbis.
- **Produtores:** `foto` é a imagem da propriedade (miniatura e destaque). Os produtores com
  `simulado: true` (Sítio Boa Vista, Quintal Agroflorestal Serra Velha e Coletivo Flores da Roça) e
  os lotes `PANC-2026-0006` a `0008` são fictícios, só para demonstração: apague antes do piloto.
  No painel, o cadastro de produtor aceita foto da propriedade.

- **Endereço do QR Code:** com `urlLote: ""`, o QR aponta para o próprio site
  (`.../lote.html#CÓDIGO`). Ao publicar num domínio definitivo, preencha
  `urlLote: "https://SEU-DOMINIO/lote.html#{codigo}"` **antes** de imprimir etiquetas.
- **Abrir o questionário:** após o CEP, `pesquisaAtiva: true` (o envio de respostas precisará de um servidor).
- **Logos:** `assets/img/logos/` (CapacitAgro, PESAGRO-RIO, FAPERJ, Universidade de Vassouras e
  Mestrado em Ciências Ambientais), no rodapé de todas as páginas e em Sobre.
- **Fotos das espécies:** `assets/img/*.jpg` e `assets/img/especies/*.jpg`; fotos das propriedades em `assets/img/produtores/`. Todas do Wikimedia Commons (domínio público ou Creative Commons). Autor, licença e link ficam no campo `credito` de cada espécie e aparecem sob a foto e em Sobre > Créditos das fotos. Ao trocar por fotos próprias, atualize ou remova o `credito`.

Os lotes `PANC-2026-0001` a `0008` são **registros de teste** da Horta Agroecológica da
Universidade de Vassouras, com dados de manejo ilustrativos. Substitua antes de divulgar.

Gerador de QR Code: `assets/js/vendor/qrcode.js` (Kazuhiko Arase, licença MIT).
